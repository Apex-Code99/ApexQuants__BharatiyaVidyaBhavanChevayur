# How ApexQuant is organised

This is my quick guide to how the main parts of ApexQuant connect. It describes the current code; it does not mean every feature has been tested in every situation.

## Main flow

1. A page under `src/routes/` displays a screen.
2. Shared query definitions in `src/lib/queries.ts` request data and handle refreshes.
3. Server functions in `src/lib/market.functions.ts` contact Yahoo Finance and return structured data.
4. The page displays the returned values and calculates some view-specific results.
5. Watchlist and paper portfolio changes are saved in browser local storage by `src/lib/store.ts`.

## Important files

| File | What it does |
| --- | --- |
| `src/lib/universe.ts` | Stock symbols, shared types, and the Apex Score formula. |
| `src/lib/market.functions.ts` | Server-side requests for quotes, price history, fundamentals, news, and symbol search. |
| `src/lib/queries.ts` | Shared query keys and refresh settings. |
| `src/lib/store.ts` | Browser state for the watchlist and simulated portfolio. |
| `src/lib/positions.ts` | Current prices used for portfolio holdings. |
| `src/routes/risk.tsx` | Portfolio risk calculations. |
| `src/routes/strategy.tsx` | Moving-average backtest. |
| `src/components/Shell.tsx` | Shared header, navigation, and search. |
| `src/start.ts` | Server middleware, including protection for server-function requests. |
| `src/server.ts` | Custom server entry and error handling. |
| `vite.config.ts` | Vite, TanStack Start, Tailwind, React, and Nitro configuration. |

## Why the market requests run on the server

The market-data requests use server functions so that the app can make requests from one place and share caching logic.

## Caching and missing data

The cache in `market.functions.ts` is in memory. It lasts only while the server process is running and is not shared between separate server instances. Some requests return cached data after a provider error. Other functions return an empty result or `null` when they cannot fetch data. The interface should not treat missing data as a confirmed zero.

## Build setup

`vite.config.ts` uses the standard Vite plugins for TanStack Start, React, Tailwind CSS, Nitro, and TypeScript path aliases. The app has a custom server entry at `src/server.ts`. If changing build configuration, run the tests, type check, and production build before relying on it.

## Current boundaries

- There is no brokerage connection or real-money trading.
- The watchlist and portfolio are local to one browser.
- There is no database or account login in this version.
- Yahoo Finance public endpoints are not a guaranteed or licensed production feed.

