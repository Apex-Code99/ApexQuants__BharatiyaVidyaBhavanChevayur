# Financial calculations in ApexQuant

These calculations are intentionally simple enough to inspect and explain. They are not a substitute for professional investment analysis. The source code is the final reference if this document and the implementation ever disagree.

## Apex Score

`computeApex()` in `src/lib/universe.ts` calculates five component scores. Each is bounded between 0 and 100, and the final score is the rounded average of the five components.

- **Valuation:** a positive P/E ratio is mapped from the configured range of 8 to 60, with lower P/E receiving a higher score. If P/E is missing or not positive, the component starts at 30.
- **Growth:** revenue growth (range -5 to 30) and earnings growth (range -10 to 40) are scored and averaged.
- **Profitability:** ROE (range 0 to 35) and net margin (range 0 to 30) are scored and averaged.
- **Health:** debt-to-equity (range 0 to 2.5, lower is better) and current ratio (range 0.5 to 2.5, higher is better) are scored and averaged.
- **Momentum:** 80% comes from the price's position in its 52-week range and 20% from the daily percentage move mapped from -3% to +3%. If the 52-week range is unavailable, the range part starts at 50.

For most missing metrics, the mapping function returns 50. This keeps the score deterministic but may make an incomplete stock look average rather than unknown. Always inspect the underlying values. The score does not adjust its ranges by industry and does not predict future returns.

## Returns and volatility

A daily simple return is calculated as `today close / previous close - 1`. The Risk Engine uses the standard deviation of daily portfolio returns. Annualized volatility is daily standard deviation multiplied by `sqrt(252)`, then expressed as a percentage. The 252-day convention is an estimate of the number of trading days in a year.

## Value at Risk (VaR)

- **Parametric 95% one-day VaR:** `1.645 × daily portfolio standard deviation × current portfolio value`.
- **Historical 95% one-day VaR:** sorts the observed portfolio returns and uses the return near the 5th percentile, multiplied by the current portfolio value and expressed as a loss.

VaR describes a model-based threshold, not the maximum possible loss. It depends on the sample and assumptions.

## Beta

Beta is estimated as the covariance of portfolio daily returns and S&P 500 daily returns divided by the variance of S&P 500 returns. The app aligns the price series by matching dates before comparing them.

## Maximum drawdown

The app compounds the daily portfolio returns into an equity curve. It tracks the highest value reached so far and calculates the drop from that peak. Maximum drawdown is the largest such drop over the selected history.

## Moving-average backtest

The Strategy Lab calculates fast and slow simple moving averages from daily closing prices. A position opens when the fast average crosses above the slow average and closes when it crosses below. It compares the strategy curve with a buy-and-hold curve.

The current backtest is educational. It does not fully include brokerage, taxes, slippage, market impact, dividend handling, or all execution timing details. Some summary statistics are simplified. A backtest result is not a prediction or a promise of future performance.

## Paper portfolio

The starting balance is $100,000 in simulated cash. Cash is stored in USD; INR trade values are converted using the USD/INR rate passed into the transaction function. Buying more of an existing position recalculates the average purchase price using a quantity-weighted average. The app rejects invalid quantities and prices, unaffordable buys, and sells for shares that are not held.
