import { createFileRoute } from "@tanstack/react-router";
import { Brain, Globe, Lightbulb, ShieldCheck, Target } from "lucide-react";
import { Panel } from "@/components/kit";

export const Route = createFileRoute("/impact")({
  head: () => ({ meta: [
    { title: "Innovate for Impact — ApexQuant" },
    { name: "description", content: "The four retail-investing problems ApexQuant solves, built for Pragati Tech Fest." },
    { property: "og:title", content: "Innovate for Impact — ApexQuant" },
    { property: "og:description", content: "Making institutional-grade equity analysis accessible, explainable, and free." },
  ] }),
  component: Impact,
});

const P = [
  { icon: Target, c: "text-destructive", t: "Problem 1: Retail Speculation", d: 'Unregulated social media tips and influencer "analysis" lead retail investors into poor decisions. We replace speculation with deterministic, audited mathematical models that anyone can verify.' },
  { icon: Brain, c: "text-warning", t: "Problem 2: Black-Box AI Hallucination", d: "Financial dashboards can obscure how scores are produced. ApexQuant uses a fixed, inspectable scoring formula and shows the underlying metrics." },
  { icon: ShieldCheck, c: "text-success", t: "Problem 3: The $24,000 Terminal Paywall", d: "Institutional tools — scenario modeling, 95% VaR, factor decomposition — sit behind expensive paywalls. We democratize these tools for every investor at zero cost." },
  { icon: Globe, c: "text-info", t: "Problem 4: Cross-Border Fragmentation", d: "US and Indian markets live on separate platforms with inconsistent data. We unify both in a single transparent terminal with native currencies and market clocks." },
];

function Impact() {
  return (
    <div className="space-y-6">
      <section className="bg-grid rounded-2xl border border-border bg-card px-6 py-14 text-center">
        <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-brand text-primary-foreground"><Lightbulb className="h-9 w-9" /></div>
        <h1 className="mt-6 text-4xl font-semibold">Innovate for Impact</h1>
        <p className="mx-auto mt-4 max-w-3xl text-muted-foreground">ApexQuant was built for Pragati Tech Fest under the theme "Solutions for Pressing Current Issues." We address four problems in retail investing by making institutional-grade equity analysis accessible, explainable, and free.</p>
      </section>
      <Panel title="The Problems We Solve" sub="Why this matters now">
        <div className="grid gap-8 md:grid-cols-2">
          {P.map(({ icon: I, c, t, d }) => (
            <div key={t}><h3 className="flex items-center gap-2 font-semibold"><I className={`h-5 w-5 ${c}`} />{t}</h3><p className="mt-2 text-muted-foreground">{d}</p></div>
          ))}
        </div>
      </Panel>
      <Panel title="Data Sources" sub="Everything you see is real">
        <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
          <li>Prices, volume, indices and USD/INR: Yahoo Finance market data (NYSE, NASDAQ, NSE, BSE feeds), refreshed every 30 seconds.</li>
          <li>Fundamentals (P/E, ROE, margins, growth, debt): company financial statements via Yahoo Finance, refreshed every few hours.</li>
          <li>News: live headlines from Reuters, Bloomberg, CNBC, Economic Times, Mint and others via Yahoo Finance.</li>
          <li>Risk Engine and Strategy Lab use real historical daily closing prices.</li>
        </ul>
      </Panel>
    </div>
  );
}
