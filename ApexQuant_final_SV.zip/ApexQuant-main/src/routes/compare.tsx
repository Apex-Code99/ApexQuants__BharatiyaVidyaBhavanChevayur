import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Download, GitCompare, Plus, X } from "lucide-react";
import { snapshotQuery } from "@/lib/queries";
import { PageTitle, ApexBadge, MarketTag, StarBtn, btnGhost, input } from "@/components/kit";
import { money, big, num, pctf } from "@/lib/format";
import { setState, useStore } from "@/lib/store";
import type { Stock } from "@/lib/universe";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/compare")({
  head: () => ({ meta: [
    { title: "Peer Comparison — ApexQuant" },
    { name: "description", content: "Compare live fundamentals of US and Indian stocks side by side." },
    { property: "og:title", content: "Peer Comparison — ApexQuant" },
    { property: "og:description", content: "Side-by-side stock fundamentals matrix." },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(snapshotQuery),
  component: Compare,
});

type Row = { label: string; get: (s: Stock) => number | null; fmt: (s: Stock) => string; better: "high" | "low" | null };
const ROWS: Row[] = [
  { label: "Price", get: (s) => s.price, fmt: (s) => money(s.price, s.currency), better: null },
  { label: "Daily Change", get: (s) => s.changePct, fmt: (s) => pctf(s.changePct), better: "high" },
  { label: "P/E Ratio", get: (s) => (s.pe && s.pe > 0 ? s.pe : null), fmt: (s) => num(s.pe, 1), better: "low" },
  { label: "P/B Ratio", get: (s) => s.pb, fmt: (s) => num(s.pb), better: "low" },
  { label: "Dividend Yield", get: (s) => s.divYield, fmt: (s) => `${num(s.divYield)}%`, better: "high" },
  { label: "ROE", get: (s) => s.roe, fmt: (s) => `${num(s.roe, 1)}%`, better: "high" },
  { label: "Gross Margin", get: (s) => s.grossMargin, fmt: (s) => `${num(s.grossMargin, 1)}%`, better: "high" },
  { label: "Net Margin", get: (s) => s.netMargin, fmt: (s) => `${num(s.netMargin, 1)}%`, better: "high" },
  { label: "Revenue Growth", get: (s) => s.revenueGrowth, fmt: (s) => pctf(s.revenueGrowth), better: "high" },
  { label: "EPS Growth", get: (s) => s.epsGrowth, fmt: (s) => pctf(s.epsGrowth), better: "high" },
  { label: "Debt to Equity", get: (s) => s.debtToEquity, fmt: (s) => num(s.debtToEquity), better: "low" },
  { label: "Current Ratio", get: (s) => s.currentRatio, fmt: (s) => num(s.currentRatio), better: "high" },
  { label: "Beta", get: (s) => s.beta, fmt: (s) => num(s.beta), better: "low" },
  { label: "Market Cap (USD)", get: (s) => null, fmt: (s) => big(s.marketCap, s.currency), better: null },
];

function Compare() {
  const { data } = useSuspenseQuery(snapshotQuery);
  const { compare } = useStore();
  const [adding, setAdding] = useState(false);
  const picked = compare.map((c) => data.stocks.find((s) => s.symbol === c)).filter((s): s is Stock => !!s);
  const set = (list: string[]) => setState((s) => ({ ...s, compare: list }));
  const best = (r: Row, s: Stock) => {
    if (!r.better || picked.length < 2) return false;
    const vals = picked.map(r.get).filter((v): v is number => v != null);
    const v = r.get(s);
    return v != null && v === (r.better === "high" ? Math.max(...vals) : Math.min(...vals));
  };
  const csv = () => {
    const lines = [["Metric", ...picked.map((s) => s.display)], ["Apex Score", ...picked.map((s) => String(s.apex.total))], ...ROWS.map((r) => [r.label, ...picked.map(r.fmt)])];
    const url = URL.createObjectURL(new Blob([lines.map((l) => l.join(",")).join("\n")], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = "apexquant-compare.csv"; a.click();
  };
  return (
    <div>
      <PageTitle icon={<GitCompare className="h-6 w-6" />} extra={<button onClick={csv} className="ml-auto flex items-center gap-2 text-sm text-muted-foreground"><Download className="h-4 w-4" />Export CSV</button>}>Stock Comparison</PageTitle>
      <div className="overflow-x-auto">
        <div style={{ minWidth: 200 + picked.length * 220 }}>
          <div className="mb-4 grid gap-4" style={{ gridTemplateColumns: `200px repeat(${picked.length}, 1fr)` }}>
            <div />
            {picked.map((s) => (
              <div key={s.symbol} className="rounded-xl border border-border bg-card p-4">
                <div className="flex justify-between"><div><div className="font-semibold">{s.display}</div><div className="text-xs text-muted-foreground">{s.name}</div></div><span className="flex gap-2"><StarBtn symbol={s.symbol} /><button aria-label="Remove" onClick={() => set(compare.filter((c) => c !== s.symbol))}><X className="h-4 w-4 text-muted-foreground" /></button></span></div>
                <div className="mt-2"><MarketTag m={s.market} /></div>
              </div>
            ))}
          </div>
          <div className="rounded-xl border border-border bg-card">
            {[{ label: "Apex Score" } as const, ...ROWS].map((r) => (
              <div key={r.label} className="grid items-center border-b border-border/60 px-4 py-3" style={{ gridTemplateColumns: `200px repeat(${picked.length}, 1fr)` }}>
                <span className="text-muted-foreground">{r.label}</span>
                {picked.map((s) => "get" in r ? (
                  <span key={s.symbol} className={cn("text-center font-mono", best(r, s) && "font-semibold text-success")}>{r.label === "Market Cap (USD)" ? big((s.marketCap ?? 0) / (s.currency === "INR" ? data.usdInr : 1), "USD") : r.fmt(s)}{best(r, s) && <span className="ml-1 text-xs">best</span>}</span>
                ) : <span key={s.symbol} className="text-center"><ApexBadge v={s.apex.total} /></span>)}
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-4">
        {adding ? (
          <select autoFocus className={cn(input, "max-w-xs")} onChange={(e) => { if (e.target.value) set([...compare, e.target.value]); setAdding(false); }} onBlur={() => setAdding(false)} defaultValue="">
            <option value="">Choose a stock…</option>
            {data.stocks.filter((s) => !compare.includes(s.symbol)).map((s) => <option key={s.symbol} value={s.symbol}>{s.display} — {s.name}</option>)}
          </select>
        ) : picked.length < 4 && <button onClick={() => setAdding(true)} className={btnGhost}><Plus className="h-4 w-4" />Add Stock to Compare</button>}
      </div>
    </div>
  );
}
