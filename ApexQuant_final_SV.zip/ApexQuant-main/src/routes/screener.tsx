import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Filter } from "lucide-react";
import { snapshotQuery } from "@/lib/queries";
import { PageTitle, Change, StarBtn, ApexBadge, input } from "@/components/kit";
import { money, big, num } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/screener")({
  head: () => ({ meta: [
    { title: "Quant Screener — ApexQuant" },
    { name: "description", content: "Screen US and NSE stocks by P/E, dividend yield, growth and Apex Score." },
    { property: "og:title", content: "Quant Screener — ApexQuant" },
    { property: "og:description", content: "Filter live stocks by fundamentals." },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(snapshotQuery),
  component: Screener,
});

function Screener() {
  const { data } = useSuspenseQuery(snapshotQuery);
  const [ex, setEx] = useState<"Both" | "US" | "NSE">("Both");
  const [sector, setSector] = useState("All");
  const [cap, setCap] = useState("Any");
  const [peMin, setPeMin] = useState(""); const [peMax, setPeMax] = useState("");
  const [div, setDiv] = useState(""); const [apex, setApex] = useState(""); const [rev, setRev] = useState("");
  const sectors = [...new Set(data.stocks.map((s) => s.sector))].sort();
  const usd = (s: (typeof data.stocks)[number]) => (s.marketCap ?? 0) / (s.currency === "INR" ? data.usdInr : 1);
  const n = (v: string) => (v === "" ? null : Number(v));
  const rows = data.stocks.filter((s) =>
    (ex === "Both" || s.market === ex) && (sector === "All" || s.sector === sector) &&
    (cap === "Any" || (cap === "Mega" ? usd(s) >= 200e9 : cap === "Large" ? usd(s) >= 10e9 && usd(s) < 200e9 : usd(s) < 10e9)) &&
    (n(peMin) == null || (s.pe ?? -1) >= n(peMin)!) && (n(peMax) == null || (s.pe != null && s.pe <= n(peMax)!)) &&
    (n(div) == null || (s.divYield ?? 0) >= n(div)!) && (n(apex) == null || s.apex.total >= n(apex)!) && (n(rev) == null || (s.revenueGrowth ?? -999) >= n(rev)!),
  ).sort((a, b) => a.display.localeCompare(b.display));
  const L = ({ children }: { children: string }) => <div className="mb-2 mt-5 text-sm text-muted-foreground">{children}</div>;
  return (
    <div>
      <PageTitle icon={<Filter className="h-6 w-6" />}>Quant Screener</PageTitle>
      <div className="grid gap-6 lg:grid-cols-[300px_1fr]">
        <aside className="h-fit rounded-xl border border-border bg-card p-5">
          <h2 className="font-semibold">Filters</h2>
          <L>Exchange</L>
          <div className="grid grid-cols-3 gap-1">{(["Both", "US", "NSE"] as const).map((e) => <button key={e} onClick={() => setEx(e)} className={cn("rounded-md border py-2 text-sm", ex === e ? "border-primary/40 bg-accent text-accent-foreground" : "border-border")}>{e}</button>)}</div>
          <L>Sector</L>
          <select value={sector} onChange={(e) => setSector(e.target.value)} className={input}><option value="All">All Sectors</option>{sectors.map((s) => <option key={s}>{s}</option>)}</select>
          <L>Market Cap Bracket (USD)</L>
          <select value={cap} onChange={(e) => setCap(e.target.value)} className={input}><option>Any</option><option value="Mega">Mega (≥ $200B)</option><option value="Large">Large ($10B–$200B)</option><option value="Mid">Below $10B</option></select>
          <L>P/E Ratio Range</L>
          <div className="grid grid-cols-2 gap-2"><input className={input} placeholder="Min" value={peMin} onChange={(e) => setPeMin(e.target.value)} /><input className={input} placeholder="Max" value={peMax} onChange={(e) => setPeMax(e.target.value)} /></div>
          <L>Min Dividend Yield (%)</L><input className={input} placeholder="e.g. 1.5" value={div} onChange={(e) => setDiv(e.target.value)} />
          <L>Min Apex Score</L><input className={input} placeholder="0-100" value={apex} onChange={(e) => setApex(e.target.value)} />
          <L>Min Revenue Growth (%)</L><input className={input} placeholder="e.g. 10" value={rev} onChange={(e) => setRev(e.target.value)} />
        </aside>
        <div className="min-w-0">
          <p className="mb-3 text-muted-foreground">{rows.length} stocks match</p>
          <div className="overflow-x-auto rounded-xl border border-border bg-card">
            <table className="w-full min-w-[900px] text-sm">
              <thead className="text-muted-foreground"><tr className="border-b border-border">{["", "Symbol", "Price", "Change %", "Apex", "P/E", "Div %", "Rev Gr.", "Sector", "Mkt Cap"].map((h, i) => <th key={i} className={cn("px-3 py-3 font-medium", i > 1 && i !== 8 ? "text-right" : "text-left")}>{h}</th>)}</tr></thead>
              <tbody>
                {rows.map((s) => (
                  <tr key={s.symbol} className="border-b border-border/60 hover:bg-secondary/50">
                    <td className="px-3 py-3"><StarBtn symbol={s.symbol} /></td>
                    <td className="px-3"><Link to="/stock/$symbol" params={{ symbol: s.symbol }}><div className="font-medium">{s.display}</div><div className="text-xs text-muted-foreground">{s.name}</div></Link></td>
                    <td className="px-3 text-right font-mono">{money(s.price, s.currency)}</td>
                    <td className="px-3 text-right"><Change v={s.changePct} /></td>
                    <td className="px-3 text-right"><ApexBadge v={s.apex.total} /></td>
                    <td className="px-3 text-right font-mono">{num(s.pe, 1)}</td>
                    <td className="px-3 text-right font-mono">{num(s.divYield)}</td>
                    <td className="px-3 text-right font-mono">{num(s.revenueGrowth, 1)}</td>
                    <td className="px-3"><span className="rounded-md bg-secondary px-2 py-1 font-mono text-xs">{s.sector}</span></td>
                    <td className="px-3 text-right font-mono">{big(s.marketCap, s.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
