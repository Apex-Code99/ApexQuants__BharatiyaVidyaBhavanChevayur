import { createFileRoute } from "@tanstack/react-router";
import { useQueries, useSuspenseQuery } from "@tanstack/react-query";
import { Shield } from "lucide-react";
import { historyQuery, snapshotQuery } from "@/lib/queries";
import { PageTitle, Empty, Stat, Panel } from "@/components/kit";
import { money, num } from "@/lib/format";
import { useStore } from "@/lib/store";
import { usePositionPrices } from "@/lib/positions";

export const Route = createFileRoute("/risk")({
  head: () => ({ meta: [
    { title: "Risk Engine — ApexQuant" },
    { name: "description", content: "Value-at-Risk, drawdown, volatility and beta for your paper portfolio from real price history." },
    { property: "og:title", content: "Risk Engine — ApexQuant" },
    { property: "og:description", content: "Portfolio risk analytics on live data." },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(snapshotQuery),
  component: Risk,
});

const rets = (c: number[]) => c.slice(1).map((v, i) => v / c[i] - 1);
const mean = (a: number[]) => a.reduce((x, y) => x + y, 0) / (a.length || 1);
const sd = (a: number[]) => { const m = mean(a); return Math.sqrt(mean(a.map((x) => (x - m) ** 2))); };

function Risk() {
  const { positions } = useStore();
  const { price, usdInr } = usePositionPrices();
  const syms = [...positions.map((p) => p.symbol), "^GSPC"];
  const hs = useQueries({ queries: syms.map((s) => historyQuery(s, "1y")) });
  if (positions.length === 0) return (<div><PageTitle icon={<Shield className="h-6 w-6" />}>Risk Engine</PageTitle><Empty icon={<Shield />} title="No positions to analyze">The Risk Engine calculates VaR, drawdown, volatility, and portfolio beta from your paper trading positions using one year of real daily prices. Buy some stocks first to see your risk metrics.</Empty></div>);
  if (hs.some((h) => !h.data && !h.isError)) return (<div><PageTitle icon={<Shield className="h-6 w-6" />}>Risk Engine</PageTitle><p className="text-muted-foreground">Loading one year of price history…</p></div>);
  if (hs.some((h) => h.isError || !h.data || h.data.length < 2)) return (<div><PageTitle icon={<Shield className="h-6 w-6" />}>Risk Engine</PageTitle><Empty icon={<Shield />} title="Not enough price history">The risk metrics need at least two daily prices for every holding and the S&amp;P 500. Check the market-data connection and try again.</Empty></div>);

  const values = positions.map((p) => ((price(p.symbol) ?? p.avgPrice) * p.qty) / (p.currency === "INR" ? usdInr : 1));
  const total = values.reduce((a, b) => a + b, 0);
  const w = values.map((v) => v / total);
  // Align series by date
  const maps = hs.map((h) => new Map(h.data!.map((p) => [new Date(p.t).toISOString().slice(0, 10), p.c])));
  const dates = [...maps[0].keys()].filter((d) => maps.every((m) => m.has(d)));
  if (dates.length < 3) return (<div><PageTitle icon={<Shield className="h-6 w-6" />}>Risk Engine</PageTitle><Empty icon={<Shield />} title="Not enough matching dates">The available price histories do not have enough matching trading days to calculate risk metrics reliably.</Empty></div>);
  const series = maps.map((m) => dates.map((d) => m.get(d)!));
  const R = series.map(rets);
  const port = R[0].map((_, i) => positions.reduce((a, _p, j) => a + w[j] * R[j][i], 0));
  const mkt = R[R.length - 1];
  const vol = sd(port);
  const var95 = 1.645 * vol * total;
  const annVol = vol * Math.sqrt(252) * 100;
  const cov = mean(port.map((x, i) => (x - mean(port)) * (mkt[i] - mean(mkt))));
  const beta = cov / (sd(mkt) ** 2 || 1);
  let peak = 1, eq = 1, mdd = 0;
  port.forEach((r) => { eq *= 1 + r; peak = Math.max(peak, eq); mdd = Math.max(mdd, (peak - eq) / peak); });
  const sorted = [...port].sort((a, b) => a - b);
  const hvar = -sorted[Math.floor(sorted.length * 0.05)] * total;

  return (
    <div>
      <PageTitle icon={<Shield className="h-6 w-6" />}>Risk Engine</PageTitle>
      <div className="grid gap-4 md:grid-cols-3">
        <Stat label="1-Day 95% VaR (parametric)" value={money(var95)} className="text-destructive" />
        <Stat label="1-Day 95% VaR (historical)" value={money(hvar)} className="text-destructive" />
        <Stat label="Max Drawdown (1Y)" value={`${(mdd * 100).toFixed(1)}%`} />
        <Stat label="Annualized Volatility" value={`${annVol.toFixed(1)}%`} />
        <Stat label="Portfolio Beta vs S&P 500" value={num(beta)} />
        <Stat label="Holdings Value" value={money(total)} />
      </div>
      <Panel className="mt-6" title="What this means">
        <ul className="list-disc space-y-2 pl-5 text-sm text-muted-foreground">
          <li>On 95% of trading days, your holdings would not lose more than about <b className="text-foreground">{money(var95)}</b> in a single day, based on the last year of real prices.</li>
          <li>The worst peak-to-trough drop of this exact mix over the past year was <b className="text-foreground">{(mdd * 100).toFixed(1)}%</b>.</li>
          <li>A beta of <b className="text-foreground">{num(beta)}</b> means your portfolio moves roughly {num(beta)}× as much as the S&P 500.</li>
          <li>Based on {dates.length} overlapping trading days. Past behaviour does not guarantee future results.</li>
        </ul>
      </Panel>
    </div>
  );
}
