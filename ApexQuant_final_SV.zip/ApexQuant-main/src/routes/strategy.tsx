import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { FlaskConical, Play, TrendingDown, TrendingUp } from "lucide-react";
import { historyQuery, snapshotQuery } from "@/lib/queries";
import { PageTitle, Panel, Stat, btnPrimary, input } from "@/components/kit";
import { money } from "@/lib/format";

export const Route = createFileRoute("/strategy")({
  head: () => ({ meta: [
    { title: "Strategy Lab — ApexQuant" },
    { name: "description", content: "Backtest SMA crossover strategies on two years of real daily prices." },
    { property: "og:title", content: "Strategy Lab — ApexQuant" },
    { property: "og:description", content: "Backtest strategies on real price history." },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(snapshotQuery),
  component: Strategy,
});

type Result = { cagr: number; sharpe: number; sortino: number; mdd: number; win: number; trades: number; final: number; ret: number; curve: { t: number; v: number; bh: number }[] };

function backtest(h: { t: number; c: number }[], fast: number, slow: number, cap: number): Result {
  const c = h.map((p) => p.c);
  const sma = (n: number, i: number) => (i + 1 < n ? null : c.slice(i + 1 - n, i + 1).reduce((a, b) => a + b, 0) / n);
  let cash = cap, sh = 0, entry = 0, wins = 0, trades = 0;
  const curve: Result["curve"] = [];
  for (let i = 0; i < c.length; i++) {
    const f = sma(fast, i), s = sma(slow, i), pf = sma(fast, i - 1), ps = sma(slow, i - 1);
    if (f != null && s != null && pf != null && ps != null) {
      if (pf <= ps && f > s && sh === 0) { sh = cash / c[i]; cash = 0; entry = c[i]; }
      else if (pf >= ps && f < s && sh > 0) { cash = sh * c[i]; sh = 0; trades++; if (c[i] > entry) wins++; }
    }
    curve.push({ t: h[i].t, v: cash + sh * c[i], bh: (cap / c[0]) * c[i] });
  }
  if (sh > 0) { trades++; if (c[c.length - 1] > entry) wins++; }
  const v = curve.map((p) => p.v);
  const r = v.slice(1).map((x, i) => x / v[i] - 1);
  const m = r.reduce((a, b) => a + b, 0) / r.length;
  const sd = Math.sqrt(r.reduce((a, b) => a + (b - m) ** 2, 0) / r.length);
  const dn = Math.sqrt(r.filter((x) => x < 0).reduce((a, b) => a + b * b, 0) / r.length);
  let peak = v[0], mdd = 0;
  v.forEach((x) => { peak = Math.max(peak, x); mdd = Math.max(mdd, (peak - x) / peak); });
  const final = v[v.length - 1];
  const yrs = (h[h.length - 1].t - h[0].t) / (365.25 * 864e5);
  return { cagr: ((final / cap) ** (1 / yrs) - 1) * 100, sharpe: sd ? (m / sd) * Math.sqrt(252) : 0, sortino: dn ? (m / dn) * Math.sqrt(252) : 0, mdd: mdd * 100, win: trades ? (wins / trades) * 100 : 0, trades, final, ret: (final / cap - 1) * 100, curve };
}

function Strategy() {
  const { data } = useSuspenseQuery(snapshotQuery);
  const qc = useQueryClient();
  const [sym, setSym] = useState("AAPL");
  const [fast, setFast] = useState("10"), [slow, setSlow] = useState("50"), [cap, setCap] = useState("10000");
  const [res, setRes] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  const stock = data.stocks.find((s) => s.symbol === sym);
  const cur = stock?.currency ?? "USD";
  const run = async () => {
    const f = parseInt(fast), s = parseInt(slow), c = Number(cap);
    if (!(Number.isInteger(f) && f > 0 && Number.isInteger(s) && s > f && Number.isFinite(c) && c > 0)) {
      setErr("Fast SMA must be a positive whole number, Slow SMA must be larger, and capital must be positive.");
      return;
    }
    setErr(""); setBusy(true);
    try {
      const h = await qc.fetchQuery(historyQuery(sym, "2y"));
      if (h.length <= s) {
        setRes(null);
        setErr(`Not enough price history for a ${s}-day Slow SMA. Try a smaller period or another stock.`);
        return;
      }
      setRes(backtest(h, f, s, c));
    } catch {
      setRes(null);
      setErr("Couldn't load price history. Check the data connection and try again.");
    } finally { setBusy(false); }
  };
  const ic = (v: number) => (v >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />);
  return (
    <div>
      <PageTitle icon={<FlaskConical className="h-6 w-6" />}>Strategy Lab</PageTitle>
      <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
        <Panel title="Strategy Configuration" className="h-fit">
          <p className="text-sm text-muted-foreground">SMA Crossover: Buy when the fast moving average crosses above the slow one. Sell when it crosses below. Tested on 2 years of real daily closes.</p>
          <label className="mb-2 mt-5 block text-sm text-muted-foreground">Stock</label>
          <select className={input} value={sym} onChange={(e) => setSym(e.target.value)}>{data.stocks.map((s) => <option key={s.symbol} value={s.symbol}>{s.display} — {s.name}</option>)}</select>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div><label className="mb-2 block text-sm text-muted-foreground">Fast SMA</label><input className={input} value={fast} onChange={(e) => setFast(e.target.value)} /></div>
            <div><label className="mb-2 block text-sm text-muted-foreground">Slow SMA</label><input className={input} value={slow} onChange={(e) => setSlow(e.target.value)} /></div>
          </div>
          <label className="mb-2 mt-4 block text-sm text-muted-foreground">Initial Capital ({cur === "INR" ? "₹" : "$"})</label>
          <input className={input} value={cap} onChange={(e) => setCap(e.target.value)} />
          {err && <p className="mt-3 text-sm text-destructive">{err}</p>}
          <button onClick={run} disabled={busy} className={`${btnPrimary} mt-5 w-full`}><Play className="h-4 w-4" />{busy ? "Running…" : "Run Backtest"}</button>
        </Panel>
        <div className="space-y-4">
          {!res ? <div className="flex h-64 items-center justify-center rounded-xl border border-dashed border-border text-muted-foreground">Configure a strategy and run the backtest.</div> : (<>
            <div className="grid gap-4 md:grid-cols-3">
              <Stat icon={ic(res.cagr)} label="CAGR" value={`${res.cagr.toFixed(1)}%`} />
              <Stat icon={ic(res.sharpe)} label="Sharpe Ratio" value={res.sharpe.toFixed(2)} />
              <Stat icon={ic(res.sortino)} label="Sortino Ratio" value={res.sortino.toFixed(2)} />
              <Stat icon={<TrendingDown className="h-4 w-4" />} label="Max Drawdown" value={`${res.mdd.toFixed(1)}%`} />
              <Stat icon={<TrendingUp className="h-4 w-4" />} label="Win Rate" value={`${res.win.toFixed(0)}%`} />
              <Stat icon={<FlaskConical className="h-4 w-4" />} label="Total Trades" value={res.trades} />
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Stat label="Final Portfolio Value" value={money(res.final, cur)} />
              <Stat label="Total Return" value={`${res.ret.toFixed(1)}%`} className={res.ret >= 0 ? "text-success" : "text-destructive"} />
            </div>
            <Panel title="Equity Curve" sub="Strategy vs. buy-and-hold over the backtest period">
              <div className="h-72">
                <ResponsiveContainer>
                  <AreaChart data={res.curve}>
                    <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                    <XAxis dataKey="t" tickFormatter={(t) => new Date(t).toLocaleDateString(undefined, { month: "short", year: "2-digit" })} stroke="var(--muted-foreground)" fontSize={11} minTickGap={40} />
                    <YAxis stroke="var(--muted-foreground)" fontSize={11} width={70} tickFormatter={(v) => money(v, cur, 0)} />
                    <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)" }} labelFormatter={(t) => new Date(t as number).toLocaleDateString()} formatter={(v: number) => money(v, cur)} />
                    <Area dataKey="bh" name="Buy & hold" stroke="var(--info)" fill="transparent" strokeDasharray="4 4" />
                    <Area dataKey="v" name="Strategy" stroke="var(--primary)" fill="var(--primary)" fillOpacity={0.15} strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </Panel>
          </>)}
        </div>
      </div>
    </div>
  );
}
