import { createFileRoute, Link } from "@tanstack/react-router";
import { DollarSign, Wallet } from "lucide-react";
import { snapshotQuery } from "@/lib/queries";
import { usePositionPrices } from "@/lib/positions";
import { PageTitle, Empty, Stat, MarketTag, btnGhost } from "@/components/kit";
import { money, pctf, tone } from "@/lib/format";
import { resetPortfolio, useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/portfolio")({
  head: () => ({ meta: [
    { title: "Paper Portfolio — ApexQuant" },
    { name: "description", content: "Paper-trade US and Indian stocks with $100K mock capital at live prices." },
    { property: "og:title", content: "Paper Portfolio — ApexQuant" },
    { property: "og:description", content: "Practice trading with live prices." },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(snapshotQuery),
  component: Portfolio,
});

function Portfolio() {
  const { cash, positions, trades } = useStore();
  const { price, usdInr } = usePositionPrices();
  const rows = positions.map((p) => {
    const px = price(p.symbol) ?? p.avgPrice;
    const fx = p.currency === "INR" ? usdInr : 1;
    const value = (px * p.qty) / fx;
    const cost = (p.avgPrice * p.qty) / fx;
    return { ...p, px, value, pnl: value - cost, pnlPct: ((px - p.avgPrice) / p.avgPrice) * 100 };
  });
  const invested = rows.reduce((a, r) => a + r.value, 0);
  const pnl = rows.reduce((a, r) => a + r.pnl, 0);
  const total = cash + invested;
  return (
    <div>
      <PageTitle icon={<Wallet className="h-6 w-6" />} extra={positions.length > 0 && <button onClick={resetPortfolio} className={cn(btnGhost, "ml-auto")}>Reset</button>}>Paper Portfolio</PageTitle>
      <div className="grid gap-4 md:grid-cols-4">
        <Stat icon={<DollarSign className="h-4 w-4" />} label="Available Cash" value={money(cash)} />
        <Stat label="Holdings Value" value={money(invested)} />
        <Stat label="Total Equity" value={money(total)} />
        <Stat label="Unrealized P&L" value={`${money(pnl)} (${pctf(((total - 100000) / 100000) * 100)})`} className={tone(pnl)} />
      </div>
      {rows.length === 0 ? (
        <Empty icon={<Wallet />} title="No positions yet">You have $100,000 in mock capital. Search for a stock, open its research page, and place your first paper trade at the live price.</Empty>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-xl border border-border bg-card">
          <table className="w-full min-w-[760px] text-sm">
            <thead className="text-muted-foreground"><tr className="border-b border-border">{["Symbol", "Market", "Qty", "Avg Cost", "Live Price", "Value (USD)", "P&L (USD)", "Weight"].map((h) => <th key={h} className="px-4 py-3 text-left font-medium">{h}</th>)}</tr></thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.symbol} className="border-b border-border/60">
                  <td className="px-4 py-3"><Link to="/stock/$symbol" params={{ symbol: r.symbol }} className="font-medium">{r.symbol.replace(".NS", "")}</Link></td>
                  <td className="px-4"><MarketTag m={r.currency === "INR" ? "NSE" : "US"} /></td>
                  <td className="px-4 font-mono">{r.qty}</td>
                  <td className="px-4 font-mono">{money(r.avgPrice, r.currency)}</td>
                  <td className="px-4 font-mono">{money(r.px, r.currency)}</td>
                  <td className="px-4 font-mono">{money(r.value)}</td>
                  <td className={cn("px-4 font-mono", tone(r.pnl))}>{money(r.pnl)} ({pctf(r.pnlPct)})</td>
                  <td className="px-4 font-mono">{((r.value / total) * 100).toFixed(1)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {trades.length > 0 && (
        <div className="mt-6 rounded-xl border border-border bg-card p-5">
          <h2 className="mb-3 font-semibold">Trade History</h2>
          <div className="space-y-1 text-sm">{trades.slice(0, 20).map((t, i) => <div key={i} className="flex justify-between font-mono"><span className={t.side === "BUY" ? "text-success" : "text-destructive"}>{t.side}</span><span>{t.qty} × {t.symbol.replace(".NS", "")}</span><span>{money(t.price, t.currency)}</span><span className="text-muted-foreground">{new Date(t.at).toLocaleString()}</span></div>)}</div>
        </div>
      )}
    </div>
  );
}
