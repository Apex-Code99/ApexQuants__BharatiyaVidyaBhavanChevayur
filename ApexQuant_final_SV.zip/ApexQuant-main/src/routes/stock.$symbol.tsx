import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowLeft, Search } from "lucide-react";
import { getStock } from "@/lib/market.functions";
import { historyQuery, snapshotQuery } from "@/lib/queries";
import { ApexBadge, Change, MarketTag, Panel, StarBtn, Empty } from "@/components/kit";
import { TradeBox } from "@/components/TradeBox";
import { money, big, num, pctf } from "@/lib/format";
import { cn } from "@/lib/utils";

const stockQuery = (symbol: string) => ({ queryKey: ["stock", symbol], queryFn: () => getStock({ data: { symbol } }), refetchInterval: 30_000 });

export const Route = createFileRoute("/stock/$symbol")({
  head: ({ params }) => ({ meta: [
    { title: `${params.symbol} Research — ApexQuant` },
    { name: "description", content: `Live price, chart, fundamentals and Apex Score for ${params.symbol}.` },
    { property: "og:title", content: `${params.symbol} Research — ApexQuant` },
    { property: "og:description", content: `Deep-dive research on ${params.symbol}.` },
  ] }),
  loader: async ({ context, params }) => {
    await Promise.all([context.queryClient.ensureQueryData(stockQuery(params.symbol)), context.queryClient.ensureQueryData(snapshotQuery)]);
  },
  component: StockPage,
});

const EXPLAIN: Record<string, string> = {
  valuation: "How cheap the stock is vs. its earnings (lower P/E scores higher).",
  growth: "Year-over-year revenue and earnings growth.",
  profitability: "Return on equity and net profit margin.",
  health: "Low debt relative to equity and enough short-term assets to cover liabilities.",
  momentum: "Where the price sits in its 52-week range, plus today's move.",
};

function StockPage() {
  const { symbol } = Route.useParams();
  const { data: s } = useSuspenseQuery(stockQuery(symbol));
  const { data: snap } = useSuspenseQuery(snapshotQuery);
  const [range, setRange] = useState<"1mo" | "6mo" | "1y" | "5y">("6mo");
  const { data: hist } = useQuery(historyQuery(symbol, range));
  if (!s) return <Empty icon={<Search />} title="Stock not found">We couldn't find live data for {symbol}. Try the search bar.</Empty>;
  const metrics: [string, string, string][] = [
    ["Market Cap", big(s.marketCap, s.currency), "Total value of all shares."],
    ["P/E Ratio", num(s.pe, 1), "Price paid for each unit of yearly profit."],
    ["P/B Ratio", num(s.pb), "Price vs. accounting book value."],
    ["Dividend Yield", `${num(s.divYield)}%`, "Yearly dividends as % of price."],
    ["ROE", `${num(s.roe, 1)}%`, "Profit generated from shareholders' money."],
    ["Net Margin", `${num(s.netMargin, 1)}%`, "Share of revenue kept as profit."],
    ["Revenue Growth", pctf(s.revenueGrowth), "Sales growth vs. a year ago."],
    ["Debt / Equity", num(s.debtToEquity), "Borrowings relative to equity."],
    ["Beta", num(s.beta), "Volatility vs. the overall market (1 = same)."],
    ["52W Range", `${money(s.low52, s.currency)} – ${money(s.high52, s.currency)}`, "Lowest and highest price in a year."],
  ];
  return (
    <div className="space-y-6">
      <Link to="/markets" className="inline-flex items-center gap-2 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" />Back to markets</Link>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-3"><h1 className="text-3xl font-semibold">{s.display}</h1><MarketTag m={s.market} /><StarBtn symbol={s.symbol} /></div>
          <p className="text-muted-foreground">{s.name} · {s.sector}{s.industry && ` · ${s.industry}`}</p>
        </div>
        <div className="text-right"><div className="font-mono text-4xl">{money(s.price, s.currency)}</div><div className="flex items-center justify-end gap-2 font-mono"><span className={s.change >= 0 ? "text-success" : "text-destructive"}>{s.change >= 0 ? "+" : ""}{s.change.toFixed(2)}</span><Change v={s.changePct} arrow /></div></div>
      </div>
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <Panel title="Price History" right={<div className="flex gap-1">{(["1mo", "6mo", "1y", "5y"] as const).map((r) => <button key={r} onClick={() => setRange(r)} className={cn("rounded-md px-2 py-1 text-xs uppercase", range === r ? "bg-accent text-accent-foreground" : "text-muted-foreground")}>{r}</button>)}</div>}>
          <div className="h-72">
            {hist ? (
              <ResponsiveContainer>
                <AreaChart data={hist}>
                  <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--primary)" stopOpacity={0.35} /><stop offset="100%" stopColor="var(--primary)" stopOpacity={0} /></linearGradient></defs>
                  <XAxis dataKey="t" tickFormatter={(t) => new Date(t).toLocaleDateString(undefined, { month: "short", year: "2-digit" })} stroke="var(--muted-foreground)" fontSize={11} minTickGap={40} />
                  <YAxis domain={["auto", "auto"]} stroke="var(--muted-foreground)" fontSize={11} width={60} />
                  <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)" }} labelFormatter={(t) => new Date(t as number).toLocaleDateString()} formatter={(v: number) => money(v, s.currency)} />
                  <Area dataKey="c" stroke="var(--primary)" fill="url(#g)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            ) : <div className="flex h-full items-center justify-center text-sm text-muted-foreground">Loading chart…</div>}
          </div>
        </Panel>
        <TradeBox s={s} usdInr={snap.usdInr} />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title={<span className="flex items-center gap-3">Apex Score <ApexBadge v={s.apex.total} /></span>} sub="Equal-weight average of five transparent factors">
          <div className="space-y-4">
            {(["valuation", "growth", "profitability", "health", "momentum"] as const).map((k) => (
              <div key={k}>
                <div className="flex justify-between text-sm"><span className="capitalize">{k}</span><span className="font-mono">{s.apex[k]}</span></div>
                <div className="mt-1 h-2 rounded-full bg-secondary"><div className="h-2 rounded-full bg-primary" style={{ width: `${s.apex[k]}%` }} /></div>
                <p className="mt-1 text-xs text-muted-foreground">{EXPLAIN[k]}</p>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Key Metrics" sub="Explained in plain English">
          <div className="divide-y divide-border">
            {metrics.map(([l, v, e]) => <div key={l} className="flex justify-between gap-4 py-2.5"><div><div className="text-sm">{l}</div><div className="text-xs text-muted-foreground">{e}</div></div><div className="font-mono">{v}</div></div>)}
          </div>
        </Panel>
      </div>
      {s.summary && <Panel title="About"><p className="text-sm leading-relaxed text-muted-foreground">{s.summary}</p></Panel>}
    </div>
  );
}
