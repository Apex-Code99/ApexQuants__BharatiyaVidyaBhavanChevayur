import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Activity } from "lucide-react";
import { snapshotQuery } from "@/lib/queries";
import { PageTitle, Change, MarketTag, StarBtn } from "@/components/kit";
import { money, big, tone } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/markets")({
  head: () => ({ meta: [
    { title: "Live Markets — ApexQuant" },
    { name: "description", content: "Live prices, volume and market cap for top US and NSE stocks." },
    { property: "og:title", content: "Live Markets — ApexQuant" },
    { property: "og:description", content: "Wall Street and Dalal Street live tape." },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(snapshotQuery),
  component: Markets,
});

function Markets() {
  const { data } = useSuspenseQuery(snapshotQuery);
  const [f, setF] = useState<"All" | "US" | "NSE">("All");
  const rows = data.stocks.filter((s) => f === "All" || s.market === f);
  const top = [...data.stocks].filter((s) => s.market === "US").sort((a, b) => (b.volume ?? 0) - (a.volume ?? 0)).slice(0, 3);
  const n = (m: string) => data.stocks.filter((s) => s.market === m).length;
  return (
    <div>
      <PageTitle icon={<Activity className="h-6 w-6" />}>Live Markets</PageTitle>
      <div className="mb-5 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">Market:
        {([["All", `All (${data.stocks.length})`], ["US", `Wall Street US (${n("US")})`], ["NSE", `Dalal Street NSE (${n("NSE")})`]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setF(k)} className={cn("rounded-full border px-4 py-1.5", f === k ? "border-primary/40 bg-accent text-accent-foreground" : "border-border text-foreground")}>{l}</button>
        ))}
      </div>
      <div className="mb-5 grid gap-4 md:grid-cols-3">
        {top.map((s) => (
          <Link key={s.symbol} to="/stock/$symbol" params={{ symbol: s.symbol }} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between"><span className="flex items-center gap-2"><Activity className="h-4 w-4 text-primary" /><b>{s.display}</b><MarketTag m={s.market} /></span><span className="font-mono text-xs text-muted-foreground">Vol: {big(s.volume)}</span></div>
            <div className="mt-3 flex items-end justify-between"><span className="font-mono text-2xl">{money(s.price, s.currency)}</span><Change v={s.changePct} arrow /></div>
          </Link>
        ))}
      </div>
      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full min-w-[800px] text-sm">
          <thead className="text-muted-foreground"><tr className="border-b border-border">{["", "Symbol", "Price", "Change", "Change %", "Volume", "Market Cap", "Exchange"].map((h, i) => <th key={i} className={cn("px-4 py-3 font-medium", i > 1 ? "text-right" : "text-left")}>{h}</th>)}</tr></thead>
          <tbody>
            {rows.map((s) => (
              <tr key={s.symbol} className="border-b border-border/60 hover:bg-secondary/50">
                <td className="px-4 py-4"><StarBtn symbol={s.symbol} /></td>
                <td className="px-4"><Link to="/stock/$symbol" params={{ symbol: s.symbol }}><div className="font-medium">{s.display}</div><div className="text-xs text-muted-foreground">{s.name}</div></Link></td>
                <td className="px-4 text-right font-mono">{money(s.price, s.currency)}</td>
                <td className={cn("px-4 text-right font-mono", tone(s.change))}>{s.change >= 0 ? "+" : ""}{s.change.toFixed(2)}</td>
                <td className="px-4 text-right"><Change v={s.changePct} /></td>
                <td className="px-4 text-right font-mono">{big(s.volume)}</td>
                <td className="px-4 text-right font-mono">{big(s.marketCap, s.currency)}</td>
                <td className="px-4 text-right"><MarketTag m={s.market} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
