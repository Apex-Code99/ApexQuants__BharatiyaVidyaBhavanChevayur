import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useSuspenseQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { TrendingUp, TrendingDown, Activity, ArrowRight, Filter, GitCompare, Newspaper, Search, Wallet } from "lucide-react";
import { snapshotQuery, newsQuery } from "@/lib/queries";
import { MarketPills } from "@/components/Shell";
import { Panel, Change, Sparkline, StarBtn, btnPrimary, btnGhost } from "@/components/kit";
import { money, big, ago, num } from "@/lib/format";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ApexQuant — Where Wall Street Meets Dalal Street" },
      { name: "description", content: "Free live equity terminal unifying US and Indian markets with explainable Apex Scores, paper trading, risk and backtests." },
      { property: "og:title", content: "ApexQuant — Where Wall Street Meets Dalal Street" },
      { property: "og:description", content: "Live US + NSE equity intelligence in one screen." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(snapshotQuery),
  component: Home,
});

function Home() {
  const { data } = useSuspenseQuery(snapshotQuery);
  const { watchlist } = useStore();
  const watch = data.stocks.filter((s) => watchlist.includes(s.symbol));
  const movers = [...data.stocks].sort((a, b) => b.changePct - a.changePct);
  const topMovers = [...movers.slice(0, 5), ...movers.slice(-5)];
  const active = [...data.stocks].filter((s) => s.market === "US").sort((a, b) => (b.volume ?? 0) - (a.volume ?? 0)).slice(0, 5);

  return (
    <div className="space-y-6">
      <section className="bg-grid relative overflow-hidden rounded-2xl border border-border bg-card px-6 py-14 md:px-10">
        <div className="flex flex-wrap gap-2"><MarketPills /></div>
        <h1 className="mt-6 text-5xl font-bold tracking-tight md:text-7xl">Apex<span className="text-primary">Quant</span></h1>
        <p className="mt-3 text-xl md:text-2xl">Where Wall Street Meets Dalal Street.</p>
        <p className="mt-5 max-w-3xl text-muted-foreground">A free equity intelligence terminal that unifies US and Indian markets in one screen. Screen stocks with a transparent five-factor Apex Score, read every metric with plain-English explanations, paper-trade with $100K of mock capital, measure risk with Value-at-Risk and drawdown, and backtest strategies — all on live market data.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/markets" className={btnPrimary}><Activity className="h-4 w-4" />Explore Live Markets</Link>
          <Link to="/screener" className={btnGhost}><Filter className="h-4 w-4" />Run the Screener</Link>
          <Link to="/portfolio" className={btnGhost}><Wallet className="h-4 w-4" />Start Paper Trading</Link>
        </div>
        <div className="mt-10 grid grid-cols-2 gap-6 md:grid-cols-4">
          {[[`${data.stocks.length}+`, "Stocks Tracked"], ["2", "Markets — US + India"], ["5", "Factor Apex Scoring"], ["$100K", "Paper Trading Capital"]].map(([a, b]) => (
            <div key={b} className="border-l-2 border-primary/50 pl-4"><div className="font-mono text-3xl">{a}</div><div className="text-sm text-muted-foreground">{b}</div></div>
          ))}
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { to: "/markets", icon: Activity, t: "Live Tape", s: "Real-time prices" },
          { to: "/screener", icon: Filter, t: "Quant Screener", s: "Filter by fundamentals" },
          { to: "/stock/AAPL", icon: Search, t: "Deep-Dive Research", s: "Analyze any stock" },
          { to: "/compare", icon: GitCompare, t: "Peer Comparison", s: "Side-by-side matrix" },
        ].map(({ to, icon: I, t, s }) => (
          <a key={t} href={to} className="rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/40">
            <I className="h-6 w-6 text-primary" /><div className="mt-3 font-semibold">{t}</div><div className="text-sm text-muted-foreground">{s}</div><ArrowRight className="mt-3 h-4 w-4 text-muted-foreground" />
          </a>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {(["US", "NSE"] as const).map((m) => (
          <Panel key={m} title={m === "US" ? "US Markets" : "Indian Markets"} sub={m === "US" ? "NYSE / NASDAQ" : "NSE / BSE"}>
            <div className="space-y-3">
              {data.indices.filter((i) => i.market === m).map((i) => (
                <div key={i.symbol} className="flex items-center justify-between"><span>{i.name}</span><span className="flex gap-4 font-mono"><span>{i.price.toLocaleString(m === "US" ? "en-US" : "en-IN", { maximumFractionDigits: 2 })}</span><Change v={i.changePct} className="w-20 justify-end" /></span></div>
              ))}
            </div>
          </Panel>
        ))}
      </div>

      <Panel title="Your Watchlist" sub="Stocks you are tracking" right={<Link to="/watchlist" className="text-sm text-primary">View all</Link>}>
        {watch.length === 0 ? <p className="text-sm text-muted-foreground">Star any stock to track it here.</p> : (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {watch.map((s) => (
              <Link key={s.symbol} to="/stock/$symbol" params={{ symbol: s.symbol }} className="rounded-xl border border-border bg-background/40 p-4 hover:border-primary/40">
                <div className="flex justify-between"><div><div className="font-semibold">{s.display}</div><div className="text-xs text-muted-foreground">{s.market}</div></div><Sparkline data={s.spark} /></div>
                <div className="mt-3 flex justify-between font-mono"><span>{money(s.price, s.currency)}</span><Change v={s.changePct} /></div>
              </Link>
            ))}
          </div>
        )}
      </Panel>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Top Movers" sub="Across both markets">
          <div className="space-y-1">
            {topMovers.map((s) => (
              <Link key={s.symbol} to="/stock/$symbol" params={{ symbol: s.symbol }} className="flex items-center justify-between rounded-md px-2 py-2 hover:bg-secondary">
                <span className="flex items-center gap-3">{s.changePct >= 0 ? <TrendingUp className="h-4 w-4 text-success" /> : <TrendingDown className="h-4 w-4 text-destructive" />}<span className="font-medium">{s.display}</span><span className="text-xs text-muted-foreground">{s.market}</span></span>
                <span className="flex gap-4 font-mono"><span>{money(s.price, s.currency)}</span><Change v={s.changePct} className="w-16 justify-end" /></span>
              </Link>
            ))}
          </div>
        </Panel>
        <Panel title="Most Active" sub="By trading volume (US)">
          <div className="space-y-1">
            {active.map((s) => (
              <Link key={s.symbol} to="/stock/$symbol" params={{ symbol: s.symbol }} className="flex items-center justify-between rounded-md px-2 py-2.5 hover:bg-secondary">
                <span className="flex items-center gap-3"><StarBtn symbol={s.symbol} /><span className="font-medium">{s.display}</span><span className="text-xs text-muted-foreground">{s.market}</span></span>
                <span className="flex gap-4 font-mono text-sm"><span className="text-muted-foreground">{big(s.volume)}</span><span>{money(s.price, s.currency)}</span><Change v={s.changePct} className="w-16 justify-end" /></span>
              </Link>
            ))}
          </div>
          <p className="mt-4 text-xs text-muted-foreground">USD/INR live: ₹{num(data.usdInr)}</p>
        </Panel>
      </div>

      <News />
    </div>
  );
}

function News() {
  const { data, isLoading } = useQuery(newsQuery);
  const [tab, setTab] = useState<"All" | "US" | "India">("All");
  const [now, setNow] = useState(0);
  useEffect(() => { setNow(Date.now()); const id = setInterval(() => setNow(Date.now()), 60_000); return () => clearInterval(id); }, []);
  const items = (data ?? []).filter((n) => tab === "All" || n.region === tab);
  return (
    <Panel title="Market News" sub="Latest live headlines" right={
      <div className="flex gap-1">{(["All", "US", "India"] as const).map((t) => <button key={t} onClick={() => setTab(t)} className={cn("rounded-md px-3 py-1 text-sm", tab === t ? "bg-accent text-accent-foreground" : "text-muted-foreground")}>{t}</button>)}</div>
    }>
      {isLoading && <p className="text-sm text-muted-foreground">Loading headlines…</p>}
      <div className="divide-y divide-border">
        {items.map((n) => (
          <a key={n.link} href={n.link} target="_blank" rel="noreferrer" className="flex gap-3 py-4 hover:opacity-90">
            <Newspaper className="mt-0.5 h-5 w-5 shrink-0 text-muted-foreground" />
            <div>
              <div>{n.title}</div>
              <div className="mt-2 flex flex-wrap items-center gap-3 text-sm">
                <span className={cn("rounded-md border px-2 py-0.5 font-mono text-xs", n.tag === "Catalyst" ? "border-success/40 bg-success/10 text-success" : n.tag === "Risk" ? "border-destructive/40 bg-destructive/10 text-destructive" : "border-info/40 bg-info/10 text-info")}>{n.tag}</span>
                <span className="text-muted-foreground">{n.publisher}</span>
                {now > 0 && <span className="text-muted-foreground">· {ago(n.time, now)}</span>}
                {n.tickers.map((t) => <span key={t} className="text-primary">${t}</span>)}
              </div>
            </div>
          </a>
        ))}
      </div>
    </Panel>
  );
}

