# Route pages

Each page in this folder is a route in the TanStack Start app. The filename determines its URL.

| File | Page |
| --- | --- |
| `index.tsx` | Command Center |
| `markets.tsx` | Live Markets |
| `screener.tsx` | Stock Screener |
| `stock.$symbol.tsx` | Individual stock research |
| `compare.tsx` | Stock comparison |
| `watchlist.tsx` | Saved watchlist |
| `portfolio.tsx` | Paper portfolio |
| `risk.tsx` | Portfolio risk estimates |
| `strategy.tsx` | Moving-average strategy test |
| `impact.tsx` | Project purpose and impact |

The shared layout is in `__root.tsx`, and the route tree is generated from these files. The detailed project structure and setup notes are in the root `README.md`.
