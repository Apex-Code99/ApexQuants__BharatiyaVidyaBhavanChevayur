import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Plus, Star } from "lucide-react";
import { snapshotQuery } from "@/lib/queries";
import { PageTitle, Change, MarketTag, ApexBadge, Sparkline, StarBtn, Empty } from "@/components/kit";
import { money, big } from "@/lib/format";
import { setState, toggleWatch, useStore } from "@/lib/store";

export const Route = createFileRoute("/watchlist")({
  head: () => ({ meta: [
    { title: "My Watchlist — ApexQuant" },
    { name: "description", content: "Track your favourite US and NSE stocks with live prices and trends." },
    { property: "og:title", content: "My Watchlist — ApexQuant" },
    { property: "og:description", content: "Your live stock watchlist." },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(snapshotQuery),
  component: Watchlist,
});

function Watchlist() {
  const { data } = useSuspenseQuery(snapshotQuery);
  const { watchlist, compare } = useStore();
  const nav = useNavigate();
  const rows = data.stocks.filter((s) => watchlist.includes(s.symbol));
  const quick = data.stocks.filter((s) => !watchlist.includes(s.symbol)).slice(0, 6);
  return (
    <div>
      <PageTitle icon={<Star className="h-6 w-6 text-warning" />} extra={<span className="text-muted-foreground">({rows.length} stocks)</span>}>My Watchlist</PageTitle>
      {rows.length === 0 ? <Empty icon={<Star />} title="Your watchlist is empty">Tap the star next to any stock to start tracking it.</Empty> : (
        <div className="overflow-x-auto rounded-xl border border-border bg-card">
          <table className="w-full min-w-[900px] text-sm">
            <thead className="text-muted-foreground"><tr className="border-b border-border">{["", "Symbol", "Market", "Price", "Change", "Volume", "Apex", "Trend (1M)", "Actions"].map((h, i) => <th key={i} className="px-4 py-3 text-left font-medium">{h}</th>)}</tr></thead>
            <tbody>
              {rows.map((s) => (
                <tr key={s.symbol} className="border-b border-border/60">
                  <td className="px-4 py-4"><StarBtn symbol={s.symbol} /></td>
                  <td className="px-4"><div className="font-medium">{s.display}</div><div className="text-xs text-muted-foreground">{s.name}</div></td>
                  <td className="px-4"><MarketTag m={s.market} /></td>
                  <td className="px-4 font-mono">{money(s.price, s.currency)}</td>
                  <td className="px-4"><Change v={s.changePct} /></td>
                  <td className="px-4 font-mono">{big(s.volume)}</td>
                  <td className="px-4"><ApexBadge v={s.apex.total} /></td>
                  <td className="px-4"><Sparkline data={s.spark} w={110} /></td>
                  <td className="space-x-1 px-4">
                    <Link to="/stock/$symbol" params={{ symbol: s.symbol }} className="rounded-md bg-accent px-2 py-1 text-xs text-accent-foreground">Research</Link>
                    <button onClick={() => { setState((x) => ({ ...x, compare: [...new Set([...compare.slice(-2), s.symbol])] })); nav({ to: "/compare" }); }} className="rounded-md bg-secondary px-2 py-1 text-xs">Compare</button>
                    <button onClick={() => toggleWatch(s.symbol)} className="rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive">Remove</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className="mt-5 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">Quick add:
        {quick.map((s) => <button key={s.symbol} onClick={() => toggleWatch(s.symbol)} className="flex items-center gap-1 rounded-md border border-border bg-card px-3 py-1.5 text-foreground"><Plus className="h-3 w-3" />{s.display}</button>)}
      </div>
    </div>
  );
}
