import { queryOptions } from "@tanstack/react-query";
import { getSnapshot, getNews, getHistory } from "./market.functions";

export const snapshotQuery = queryOptions({ queryKey: ["snapshot"], queryFn: () => getSnapshot(), refetchInterval: (q) => (q.state.data?.unavailable ? 5_000 : 30_000), staleTime: 20_000 });
export const newsQuery = queryOptions({ queryKey: ["news"], queryFn: () => getNews(), refetchInterval: 5 * 60_000, staleTime: 60_000 });
export const historyQuery = (symbol: string, range: "1mo" | "6mo" | "1y" | "2y" | "5y") =>
  queryOptions({ queryKey: ["hist", symbol, range], queryFn: () => getHistory({ data: { symbol, range } }), staleTime: 10 * 60_000 });
