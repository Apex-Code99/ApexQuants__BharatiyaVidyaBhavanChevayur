export type Market = "US" | "NSE";

export const US_SYMBOLS = ["AAPL", "MSFT", "NVDA", "GOOGL", "AMZN", "META", "TSLA", "JPM", "V", "JNJ", "WMT", "XOM", "UNH"];
export const NSE_SYMBOLS = ["RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "BHARTIARTL.NS", "ITC.NS", "SBIN.NS", "LT.NS", "HINDUNILVR.NS", "MARUTI.NS"];
export const UNIVERSE = [...US_SYMBOLS, ...NSE_SYMBOLS];

export const INDICES = [
  { symbol: "^GSPC", name: "S&P 500", market: "US" as Market },
  { symbol: "^IXIC", name: "NASDAQ", market: "US" as Market },
  { symbol: "^DJI", name: "DOW", market: "US" as Market },
  { symbol: "^NSEI", name: "NIFTY 50", market: "NSE" as Market },
  { symbol: "^BSESN", name: "SENSEX", market: "NSE" as Market },
  { symbol: "^NSEBANK", name: "BANK NIFTY", market: "NSE" as Market },
];

export type ApexScore = { total: number; valuation: number; growth: number; profitability: number; health: number; momentum: number };

export type Stock = {
  symbol: string;
  display: string;
  name: string;
  market: Market;
  currency: string;
  price: number;
  change: number;
  changePct: number;
  volume: number | null;
  marketCap: number | null;
  pe: number | null;
  pb: number | null;
  divYield: number | null;
  roe: number | null;
  grossMargin: number | null;
  netMargin: number | null;
  revenueGrowth: number | null;
  epsGrowth: number | null;
  debtToEquity: number | null;
  currentRatio: number | null;
  beta: number | null;
  sector: string;
  industry: string;
  summary: string;
  high52: number | null;
  low52: number | null;
  spark: number[];
  marketTime: number | null;
  apex: ApexScore;
};

export type IndexQuote = { symbol: string; name: string; market: Market; price: number; changePct: number };

export type NewsItem = { title: string; publisher: string; link: string; time: number; tickers: string[]; tag: "Catalyst" | "Risk" | "Neutral"; region: "US" | "India" };

export type Snapshot = { stocks: Stock[]; indices: IndexQuote[]; usdInr: number; fetchedAt: number; unavailable?: boolean };

export const displaySymbol = (s: string) => s.replace(/\.(NS|BO)$/, "");
export const marketOf = (s: string): Market => (/\.(NS|BO)$/.test(s) ? "NSE" : "US");

const clamp = (n: number) => Math.max(0, Math.min(100, n));
const lin = (v: number | null, lo: number, hi: number, invert = false) => {
  if (v == null || !isFinite(v)) return 50;
  const t = clamp(((v - lo) / (hi - lo)) * 100);
  return invert ? 100 - t : t;
};

// apex score = 5 scores from 0-100, then just the average
export function computeApex(s: Omit<Stock, "apex">): ApexScore {
  // 1. valuation: lower p/e is better, losing money (no p/e) gets 30
  let valuation = 30;
  if (s.pe != null && s.pe > 0) valuation = lin(s.pe, 8, 60, true);

  // 2. growth: revenue growth and eps growth mixed 50/50
  const growth = (lin(s.revenueGrowth, -5, 30) + lin(s.epsGrowth, -10, 40)) / 2;

  // 3. profitability: roe and net margin
  const profitability = (lin(s.roe, 0, 35) + lin(s.netMargin, 0, 30)) / 2;

  // 4. health: less debt is better, higher current ratio is better
  const health = (lin(s.debtToEquity, 0, 2.5, true) + lin(s.currentRatio, 0.5, 2.5)) / 2;

  // 5. momentum: where the price sits in its 52 week range + today's move
  let range = 50;
  if (s.high52 && s.low52 && s.high52 > s.low52) range = ((s.price - s.low52) / (s.high52 - s.low52)) * 100;
  const momentum = clamp(range * 0.8 + lin(s.changePct, -3, 3) * 0.2);

  const total = (valuation + growth + profitability + health + momentum) / 5;
  return {
    valuation: Math.round(valuation), growth: Math.round(growth), profitability: Math.round(profitability),
    health: Math.round(health), momentum: Math.round(momentum), total: Math.round(total),
  };
}
