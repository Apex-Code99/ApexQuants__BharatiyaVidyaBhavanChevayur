// Small helpers for showing numbers on screen.
// Every helper shows "—" when the value is missing.

type MaybeNumber = number | null | undefined;

// True when the value is missing or not a real number (NaN / Infinity).
function isMissing(v: MaybeNumber): v is null | undefined {
  return v == null || !isFinite(v);
}

// Currency symbol: rupee for INR, dollar for everything else.
export function sym(currency: string) {
  if (currency === "INR") return "₹";
  return "$";
}

// Price with symbol, e.g. $1,234.50 or ₹1,23,450.00 (Indian digit grouping).
export function money(v: MaybeNumber, currency = "USD", decimals = 2) {
  if (isMissing(v)) return "—";
  const locale = currency === "INR" ? "en-IN" : "en-US";
  const text = v.toLocaleString(locale, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return sym(currency) + text;
}

// Short form for big numbers: 2.5T, 340.00B, 12.00M, 4.50K.
export function big(v: MaybeNumber, currency?: string) {
  if (isMissing(v)) return "—";
  const prefix = currency ? sym(currency) : "";
  const size = Math.abs(v);

  if (size >= 1e12) return prefix + (v / 1e12).toFixed(2) + "T";
  if (size >= 1e9) return prefix + (v / 1e9).toFixed(2) + "B";
  if (size >= 1e6) return prefix + (v / 1e6).toFixed(2) + "M";
  if (size >= 1e3) return prefix + (v / 1e3).toFixed(2) + "K";
  return prefix + v.toFixed(2);
}

// Percent with a + sign for gains, e.g. +1.25% or -0.80%.
export function pctf(v: MaybeNumber, decimals = 2) {
  if (isMissing(v)) return "—";
  const sign = v >= 0 ? "+" : "";
  return sign + v.toFixed(decimals) + "%";
}

// Plain number with fixed decimals.
export function num(v: MaybeNumber, decimals = 2) {
  if (isMissing(v)) return "—";
  return v.toFixed(decimals);
}

// Green text for gains, red for losses.
export function tone(v: number) {
  if (v >= 0) return "text-success";
  return "text-destructive";
}

// "5m ago", "3h ago", "2d ago" for news timestamps.
export function ago(time: number, now: number) {
  const minutes = Math.max(0, Math.round((now - time) / 60000));
  if (minutes < 60) return minutes + "m ago";

  const hours = Math.round(minutes / 60);
  if (hours < 24) return hours + "h ago";

  return Math.round(hours / 24) + "d ago";
}

// Is the exchange open right now?
// Checks weekdays and normal trading hours only (no holiday calendar).
// openMin / closeMin are minutes after midnight in the exchange's time zone.
export function marketOpen(timeZone: string, openMin: number, closeMin: number, now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    weekday: "short",
    hour: "numeric",
    minute: "numeric",
    hour12: false,
  }).formatToParts(now);

  let weekday = "";
  let hour = 0;
  let minute = 0;
  for (const p of parts) {
    if (p.type === "weekday") weekday = p.value;
    if (p.type === "hour") hour = parseInt(p.value) % 24; // some browsers say "24" for midnight
    if (p.type === "minute") minute = parseInt(p.value);
  }

  if (weekday === "Sat" || weekday === "Sun") return false;
  const minutesNow = hour * 60 + minute;
  return minutesNow >= openMin && minutesNow < closeMin;
}
