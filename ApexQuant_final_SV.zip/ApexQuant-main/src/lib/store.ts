import { useSyncExternalStore, useEffect } from "react";

export type Position = { symbol: string; qty: number; avgPrice: number; currency: string };
export type Trade = { symbol: string; side: "BUY" | "SELL"; qty: number; price: number; currency: string; at: number };
type State = { watchlist: string[]; cash: number; positions: Position[]; trades: Trade[]; compare: string[] };

const KEY = "apexquant:v1";
const initial: State = { watchlist: ["AAPL", "NVDA", "TCS.NS", "HDFCBANK.NS"], cash: 100000, positions: [], trades: [], compare: ["AAPL", "MSFT"] };
let state: State = initial;
let loaded = false;
const subs = new Set<() => void>();

function emit() {
  if (typeof window !== "undefined") localStorage.setItem(KEY, JSON.stringify(state));
  subs.forEach((f) => f());
}
export function setState(fn: (s: State) => State) { state = fn(state); emit(); }

export function useStore() {
  useEffect(() => {
    if (loaded) return;
    loaded = true;
    try { const s = localStorage.getItem(KEY); if (s) { state = { ...initial, ...JSON.parse(s) }; subs.forEach((f) => f()); } } catch {}
  }, []);
  return useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, () => state, () => initial);
}

export const toggleWatch = (sym: string) =>
  setState((s) => ({ ...s, watchlist: s.watchlist.includes(sym) ? s.watchlist.filter((x) => x !== sym) : [...s.watchlist, sym] }));

// cash is kept in dollars, indian stocks get converted with the live usd/inr rate
export function trade(sym: string, side: "BUY" | "SELL", qty: number, price: number, currency: string, usdInr: number): string | null {
  // Reject invalid orders before changing cash, holdings, or trade history.
  if (!sym.trim()) return "Choose a stock before placing an order.";
  if (side !== "BUY" && side !== "SELL") return "Choose BUY or SELL.";
  if (!Number.isSafeInteger(qty) || qty <= 0) return "Quantity must be a positive whole number.";
  if (!Number.isFinite(price) || price <= 0) return "The stock price must be a positive number.";
  if (currency !== "USD" && currency !== "INR") return "This currency is not supported.";
  if (currency === "INR" && (!Number.isFinite(usdInr) || usdInr <= 0)) {
    return "A valid USD/INR exchange rate is required for Indian stocks.";
  }

  // Cash is stored in USD, so convert Indian-stock order values before checking it.
  let cost = price * qty;
  if (currency === "INR") cost = cost / usdInr;
  if (!Number.isFinite(cost)) return "The order value could not be calculated.";

  const pos = state.positions.find((p) => p.symbol === sym);
  let positions = state.positions;
  let cash = state.cash;

  if (side === "BUY") {
    // step 3: can we afford it
    if (cost > cash) return "Not enough paper cash for this order.";
    cash = cash - cost;
    if (pos) {
      // already own some, so work out the new average buy price
      const newQty = pos.qty + qty;
      const newAvg = (pos.avgPrice * pos.qty + price * qty) / newQty;
      positions = positions.map((p) => (p.symbol === sym ? { ...p, qty: newQty, avgPrice: newAvg } : p));
    } else {
      positions = [...positions, { symbol: sym, qty, avgPrice: price, currency }];
    }
  } else {
    // step 4: can only sell what we have
    if (!pos || pos.qty < qty) return "You don't hold enough shares to sell.";
    cash = cash + cost;
    positions = positions.map((p) => (p.symbol === sym ? { ...p, qty: p.qty - qty } : p));
    positions = positions.filter((p) => p.qty > 0);
  }

  // step 5: save it and add to trade history
  const newTrade: Trade = { symbol: sym, side, qty, price, currency, at: Date.now() };
  setState((s) => ({ ...s, cash, positions, trades: [newTrade, ...s.trades] }));
  return null;
}
export const resetPortfolio = () => setState((s) => ({ ...s, cash: 100000, positions: [], trades: [] }));
