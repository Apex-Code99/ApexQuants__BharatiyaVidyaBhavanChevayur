import { useQueries, useSuspenseQuery } from "@tanstack/react-query";
import { snapshotQuery } from "./queries";
import { getStock } from "./market.functions";
import { useStore } from "./store";

// Gives the live price for every stock in the paper portfolio.
export function usePositionPrices() {
  const { data } = useSuspenseQuery(snapshotQuery);
  const { positions } = useStore();

  // Most stocks are already in the main market snapshot.
  // Anything else the user bought (found via search) is fetched on its own.
  const missing = positions.filter((p) => {
    const inSnapshot = data.stocks.some((s) => s.symbol === p.symbol);
    return !inSnapshot;
  });

  const extraQueries = useQueries({
    queries: missing.map((p) => ({
      queryKey: ["stock", p.symbol],
      queryFn: () => getStock({ data: { symbol: p.symbol } }),
      refetchInterval: 30_000, // refresh every 30 seconds
    })),
  });

  // Look in the snapshot first, then in the extra lookups.
  function price(symbol: string) {
    const fromSnapshot = data.stocks.find((s) => s.symbol === symbol);
    if (fromSnapshot) return fromSnapshot.price;

    const fromExtra = extraQueries.find((q) => q.data?.symbol === symbol);
    return fromExtra?.data?.price;
  }

  return { price, usdInr: data.usdInr };
}
