import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { UNIVERSE, INDICES, computeApex, displaySymbol, marketOf, type Stock, type Snapshot, type NewsItem } from "./universe";

const UA = "Mozilla/5.0";

// Per-isolate caches (data source: Yahoo Finance public market data)
const cache = new Map<string, { t: number; v: unknown }>();
async function cached<T>(key: string, ttlMs: number, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.t < ttlMs) return hit.v as T;
  try {
    const v = await fn();
    cache.set(key, { t: Date.now(), v });
    return v;
  } catch (e) {
    if (hit) return hit.v as T; // serve last good data if the source is throttling
    throw e;
  }
}

async function getSession(): Promise<{ cookie: string; crumb: string }> {
  return cached("session", 30 * 60_000, async () => {
    const r = await fetch("https://fc.yahoo.com", { headers: { "User-Agent": UA }, redirect: "manual" });
    const raw = r.headers.get("set-cookie") ?? "";
    const cookie = raw.split(/,(?=\s*\w+=)/).map((c) => c.split(";")[0].trim()).filter(Boolean).join("; ");
    const c = await fetch("https://query1.finance.yahoo.com/v1/test/getcrumb", { headers: { "User-Agent": UA, Cookie: cookie } });
    const crumb = (await c.text()).trim();
    if (!crumb || crumb.includes("<")) throw new Error("Market data session unavailable");
    return { cookie, crumb };
  });
}

async function yf(url: string, auth = false): Promise<any> {
  const headers: Record<string, string> = { "User-Agent": UA };
  let u = url;
  if (auth) {
    const s = await getSession();
    headers['Cookie'] = s.cookie;
    u += (u.includes("?") ? "&" : "?") + "crumb=" + encodeURIComponent(s.crumb);
  }
  const r = await fetch(u, { headers });
  if (!r.ok) {
    if (auth && r.status === 401) cache.delete("session");
    throw new Error(`Market data request failed (${r.status})`);
  }
  return r.json();
}

const raw = (o: any): number | null => (o && typeof o.raw === "number" ? o.raw : typeof o === "number" ? o : null);
const pct = (o: any) => { const v = raw(o); return v == null ? null : v * 100; };

async function chartQuote(symbol: string) {
  const j = await yf(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=5d&interval=1d`);
  const m = j?.chart?.result?.[0]?.meta ?? {};
  const prev = m.chartPreviousClose ?? m.previousClose ?? m.regularMarketPrice;
  return {
    symbol, longName: m.longName, shortName: m.shortName, currency: m.currency, regularMarketPrice: m.regularMarketPrice,
    regularMarketChange: m.regularMarketPrice - prev, regularMarketChangePercent: m.regularMarketChangePercent ?? ((m.regularMarketPrice - prev) / prev) * 100,
    regularMarketVolume: m.regularMarketVolume, fiftyTwoWeekHigh: m.fiftyTwoWeekHigh, fiftyTwoWeekLow: m.fiftyTwoWeekLow, regularMarketTime: m.regularMarketTime,
  };
}

async function quotes(symbols: string[]): Promise<any[]> {
  return cached(`q:${symbols.join(",")}`, 15_000, async () => {
    try {
      const j = await yf(`https://query1.finance.yahoo.com/v7/finance/quote?symbols=${encodeURIComponent(symbols.join(","))}`, true);
      const r = (j?.quoteResponse?.result ?? []) as any[];
      if (r.length) return r;
      throw new Error("empty");
    } catch {
      const r = await Promise.all(symbols.map((s) => chartQuote(s).catch((e) => { console.error("chartQuote", s, String(e)); return null; })));
      const ok = r.filter(Boolean);
      if (!ok.length) throw new Error("Market data temporarily unavailable");
      return ok;
    }
  });
}

async function inBatches<T, R>(items: T[], size: number, fn: (t: T) => Promise<R>): Promise<R[]> {
  const out: R[] = [];
  for (let i = 0; i < items.length; i += size) out.push(...(await Promise.all(items.slice(i, i + size).map(fn))));
  return out;
}

async function summary(symbol: string) {
  return cached(`sum:${symbol}`, 6 * 3600_000, async () => {
    const j = await yf(`https://query1.finance.yahoo.com/v10/finance/quoteSummary/${encodeURIComponent(symbol)}?modules=financialData,defaultKeyStatistics,summaryDetail,assetProfile`, true);
    const r = j?.quoteSummary?.result?.[0];
    if (!r) throw new Error("no summary");
    return r;
  }).catch(() => ({} as any));
}

async function spark(symbol: string) {
  return cached(`spark:${symbol}`, 10 * 60_000, async () => {
    {
      const j = await yf(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=1mo&interval=1d`);
      const c: (number | null)[] = j?.chart?.result?.[0]?.indicators?.quote?.[0]?.close ?? [];
      return c.filter((x): x is number => typeof x === "number");
    }
  }).catch(() => [] as number[]);
}

async function buildStocks(symbols: string[]): Promise<Stock[]> {
  const qs = await quotes(symbols);
  const out = await inBatches(qs.filter((q) => q.regularMarketPrice != null), 6, async (q) => {
    const [s, sp] = await Promise.all([summary(q.symbol), spark(q.symbol)]);
    const fd = s.financialData ?? {}, ks = s.defaultKeyStatistics ?? {}, sd = s.summaryDetail ?? {}, ap = s.assetProfile ?? {};
    const de = raw(fd.debtToEquity);
    const base = {
      symbol: q.symbol, display: displaySymbol(q.symbol), name: q.longName ?? q.shortName ?? q.symbol,
      market: marketOf(q.symbol), currency: q.currency ?? (marketOf(q.symbol) === "NSE" ? "INR" : "USD"),
      price: q.regularMarketPrice, change: q.regularMarketChange ?? 0, changePct: q.regularMarketChangePercent ?? 0,
      volume: q.regularMarketVolume ?? null, marketCap: q.marketCap ?? raw(sd.marketCap) ?? null,
      pe: q.trailingPE ?? raw(sd.trailingPE), pb: q.priceToBook ?? raw(ks.priceToBook),
      divYield: pct(sd.dividendYield), roe: pct(fd.returnOnEquity), grossMargin: pct(fd.grossMargins), netMargin: pct(fd.profitMargins),
      revenueGrowth: pct(fd.revenueGrowth), epsGrowth: pct(fd.earningsGrowth), debtToEquity: de == null ? null : de / 100,
      currentRatio: raw(fd.currentRatio), beta: raw(sd.beta) ?? raw(ks.beta),
      sector: ap.sector ?? "—", industry: ap.industry ?? "", summary: ap.longBusinessSummary ?? "",
      high52: q.fiftyTwoWeekHigh ?? null, low52: q.fiftyTwoWeekLow ?? null, spark: sp,
      marketTime: q.regularMarketTime ?? null,
    };
    return { ...base, apex: computeApex(base) } as Stock;
  });
  const order = new Map(symbols.map((s, i) => [s, i]));
  return out.sort((a, b) => (order.get(a.symbol) ?? 0) - (order.get(b.symbol) ?? 0));
}

export const getSnapshot = createServerFn({ method: "GET" }).handler(async (): Promise<Snapshot> => {
  try { return await cached("snapshot", 20_000, loadSnapshot); }
  catch { return { stocks: [], indices: [], usdInr: 0, fetchedAt: Date.now(), unavailable: true }; }
});

async function loadSnapshot(): Promise<Snapshot> {
  const [stocks, idx] = await Promise.all([buildStocks(UNIVERSE), quotes([...INDICES.map((i) => i.symbol), "INR=X"])]);
  const fx = idx.find((q) => q.symbol === "INR=X")?.regularMarketPrice ?? 83;
  return {
    stocks,
    usdInr: fx,
    indices: INDICES.map((i) => {
      const q = idx.find((x) => x.symbol === i.symbol);
      return { ...i, price: q?.regularMarketPrice ?? 0, changePct: q?.regularMarketChangePercent ?? 0 };
    }),
    fetchedAt: Date.now(),
  };
}

export const getStock = createServerFn({ method: "GET" })
  .validator((d: unknown) => z.object({ symbol: z.string().min(1).max(20) }).parse(d))
  .handler(async ({ data }) => {
    try { const [s] = await buildStocks([data.symbol.toUpperCase()]); return s ?? null; } catch { return null; }
  });

export const getHistory = createServerFn({ method: "GET" })
  .validator((d: unknown) => z.object({ symbol: z.string().min(1).max(20), range: z.enum(["1mo", "6mo", "1y", "2y", "5y"]) }).parse(d))
  .handler(async ({ data }) => cached(`hist:${data.symbol}:${data.range}`, 30 * 60_000, async () => {
    const j = await yf(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(data.symbol)}?range=${data.range}&interval=1d`);
    const r = j?.chart?.result?.[0];
    const ts: number[] = r?.timestamp ?? [];
    const c: (number | null)[] = r?.indicators?.quote?.[0]?.close ?? [];
    return ts.map((t, i) => ({ t: t * 1000, c: c[i] })).filter((p): p is { t: number; c: number } => typeof p.c === "number");
  }));

const POS = /beat|surge|soar|jump|rall|record|upgrade|gain|rise|boost|approv|win|strong|expand|launch/i;
const NEG = /miss|fall|drop|plung|slump|cut|downgrade|probe|lawsuit|fine|loss|weak|warn|crash|tumbl|slow/i;

export const getNews = createServerFn({ method: "GET" }).handler(async (): Promise<NewsItem[]> => cached("news", 5 * 60_000, async () => {
  const qs: { q: string; region: "US" | "India" }[] = [
    { q: "stock market", region: "US" }, { q: "Wall Street", region: "US" }, { q: "Nvidia", region: "US" },
    { q: "Sensex Nifty", region: "India" }, { q: "Reliance Industries", region: "India" }, { q: "Infosys TCS", region: "India" },
  ];
  const all = await Promise.all(qs.map(async ({ q, region }) => {
    try {
      const j = await yf(`https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&quotesCount=0&newsCount=8`);
      return (j?.news ?? []).map((n: any): NewsItem => ({
        title: n.title, publisher: n.publisher, link: n.link, time: (n.providerPublishTime ?? 0) * 1000,
        tickers: (n.relatedTickers ?? []).slice(0, 3).map(displaySymbol),
        tag: POS.test(n.title) ? "Catalyst" : NEG.test(n.title) ? "Risk" : "Neutral", region,
      }));
    } catch { return []; }
  }));
  const seen = new Set<string>();
  return all.flat().filter((n) => n.title && !seen.has(n.title) && seen.add(n.title)).sort((a, b) => b.time - a.time).slice(0, 30);
}));

export const searchSymbols = createServerFn({ method: "GET" })
  .validator((d: unknown) => z.object({ q: z.string().min(1).max(50) }).parse(d))
  .handler(async ({ data }) => {
    const j = await yf(`https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(data.q)}&quotesCount=10&newsCount=0`);
    return ((j?.quotes ?? []) as any[])
      .filter((q) => q.quoteType === "EQUITY" && (!q.symbol.includes(".") || /\.(NS|BO)$/.test(q.symbol)))
      .map((q) => ({ symbol: q.symbol as string, name: (q.longname ?? q.shortname ?? q.symbol) as string, exchange: (q.exchDisp ?? "") as string }));
  });

