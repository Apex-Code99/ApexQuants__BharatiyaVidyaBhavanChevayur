import { beforeEach, describe, expect, it } from "vitest";
import { resetPortfolio, setState, trade } from "@/lib/store";

const emptyState = {
  watchlist: [],
  cash: 100_000,
  positions: [],
  trades: [],
  compare: [],
};

describe("paper portfolio transactions", () => {
  beforeEach(() => {
    localStorage.clear();
    setState(() => ({ ...emptyState, positions: [], trades: [], watchlist: [], compare: [] }));
    resetPortfolio();
  });

  it("buys a US stock and reduces simulated cash", () => {
    expect(trade("AAPL", "BUY", 2, 100, "USD", 83)).toBeNull();
    const stored = JSON.parse(localStorage.getItem("apexquant:v1")!);
    expect(stored.cash).toBe(99_800);
    expect(stored.positions).toEqual([
      expect.objectContaining({ symbol: "AAPL", qty: 2, avgPrice: 100, currency: "USD" }),
    ]);
    expect(stored.trades).toHaveLength(1);
  });

  it("converts Indian-stock order value to USD cash", () => {
    expect(trade("TCS.NS", "BUY", 1, 8300, "INR", 83)).toBeNull();
    const stored = JSON.parse(localStorage.getItem("apexquant:v1")!);
    expect(stored.cash).toBe(99_900);
  });

  it("rejects invalid quantities and exchange rates without changing the portfolio", () => {
    expect(trade("AAPL", "BUY", -1, 100, "USD", 83)).toContain("Quantity");
    expect(trade("TCS.NS", "BUY", 1, 8300, "INR", 0)).toContain("exchange rate");
    const stored = JSON.parse(localStorage.getItem("apexquant:v1")!);
    expect(stored.cash).toBe(100_000);
    expect(stored.positions).toHaveLength(0);
    expect(stored.trades).toHaveLength(0);
  });

  it("does not allow buying more than available cash or selling shares not owned", () => {
    expect(trade("AAPL", "BUY", 2_000, 100, "USD", 83)).toContain("Not enough");
    expect(trade("AAPL", "SELL", 1, 100, "USD", 83)).toContain("don't hold");
  });

  it("rejects non-positive prices and fractional share quantities", () => {
    expect(trade("AAPL", "BUY", 1.5, 100, "USD", 83)).toContain("whole number");
    expect(trade("AAPL", "BUY", 1, 0, "USD", 83)).toContain("positive number");
  });

  it("updates average purchase price when buying the same stock again", () => {
    expect(trade("AAPL", "BUY", 2, 100, "USD", 83)).toBeNull();
    expect(trade("AAPL", "BUY", 2, 120, "USD", 83)).toBeNull();
    const stored = JSON.parse(localStorage.getItem("apexquant:v1")!);
    expect(stored.positions[0]).toMatchObject({ symbol: "AAPL", qty: 4, avgPrice: 110 });
    expect(stored.cash).toBe(99_560);
  });

  it("returns cash when selling an owned position", () => {
    expect(trade("AAPL", "BUY", 2, 100, "USD", 83)).toBeNull();
    expect(trade("AAPL", "SELL", 1, 110, "USD", 83)).toBeNull();
    const stored = JSON.parse(localStorage.getItem("apexquant:v1")!);
    expect(stored.cash).toBe(99_910);
    expect(stored.positions[0]).toMatchObject({ symbol: "AAPL", qty: 1, avgPrice: 100 });
  });
});
