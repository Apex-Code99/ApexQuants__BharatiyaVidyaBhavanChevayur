import { describe, expect, it } from "vitest";
import { computeApex } from "@/lib/universe";

const stock = (overrides: Record<string, unknown> = {}) => ({
  symbol: "TEST",
  display: "TEST",
  name: "Test Company",
  market: "US",
  currency: "USD",
  price: 100,
  change: 1,
  changePct: 1,
  volume: 1000,
  marketCap: 1_000_000,
  pe: 20,
  pb: 3,
  divYield: 0,
  roe: 0.2,
  grossMargin: 0.4,
  netMargin: 0.15,
  revenueGrowth: 0.1,
  epsGrowth: 0.12,
  debtToEquity: 0.5,
  currentRatio: 1.5,
  beta: 1,
  sector: "Technology",
  industry: "Software",
  summary: "",
  high52: 120,
  low52: 80,
  spark: [90, 95, 100],
  marketTime: 1,
  ...overrides,
}) as never;

describe("computeApex", () => {
  it("returns component scores and total within the 0–100 range", () => {
    const score = computeApex(stock());
    for (const value of Object.values(score)) {
      expect(value).toBeGreaterThanOrEqual(0);
      expect(value).toBeLessThanOrEqual(100);
    }
    expect(score.total).toBe(Math.round(
      (score.valuation + score.growth + score.profitability + score.health + score.momentum) / 5,
    ));
  });

  it("uses the documented fallback for missing valuation and neutral missing metrics", () => {
    const score = computeApex(stock({
      pe: null,
      revenueGrowth: null,
      epsGrowth: null,
      roe: null,
      netMargin: null,
      debtToEquity: null,
      currentRatio: null,
    }));
    expect(score.valuation).toBe(30);
    expect(score.growth).toBe(50);
    expect(score.profitability).toBe(50);
    expect(score.health).toBe(50);
  });

  it("is deterministic for the same input", () => {
    expect(computeApex(stock())).toEqual(computeApex(stock()));
  });
});
