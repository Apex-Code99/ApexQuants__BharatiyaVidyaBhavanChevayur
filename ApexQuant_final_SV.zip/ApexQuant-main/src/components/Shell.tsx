import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";
import { Activity, Filter, FlaskConical, GitCompare, Info, Lightbulb, LayoutGrid, Radio, Search, Shield, Star, Wallet } from "lucide-react";
import { snapshotQuery } from "@/lib/queries";
import { searchSymbols } from "@/lib/market.functions";
import { marketOpen, money, pctf, big } from "@/lib/format";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Command Center", icon: LayoutGrid },
  { to: "/markets", label: "Live Markets", icon: Activity },
  { to: "/screener", label: "Screener", icon: Filter },
  { to: "/compare", label: "Compare", icon: GitCompare },
  { to: "/watchlist", label: "Watchlist", icon: Star },
  { to: "/portfolio", label: "Portfolio", icon: Wallet },
  { to: "/risk", label: "Risk Engine", icon: Shield },
  { to: "/strategy", label: "Strategy Lab", icon: FlaskConical },
  { to: "/impact", label: "Innovate for Impact", icon: Lightbulb },
] as const;

export function useMarketClock() {
  const [s, set] = useState<{ nyse: boolean; nse: boolean } | null>(null);
  useEffect(() => {
    const f = () => set({ nyse: marketOpen("America/New_York", 570, 960), nse: marketOpen("Asia/Kolkata", 555, 930) });
    f();
    const id = setInterval(f, 30_000);
    return () => clearInterval(id);
  }, []);
  return s;
}

export function MarketPills() {
  const c = useMarketClock();
  const pill = (name: string, open?: boolean) => (
    <span className={cn("inline-flex items-center gap-2 rounded-md border px-3 py-1 font-mono text-xs", open ? "border-success/40 bg-success/10 text-success" : "border-border text-muted-foreground")}>
      <span className={cn("h-1.5 w-1.5 rounded-full", open ? "bg-success" : "bg-muted-foreground")} />
      {name} · {c == null ? "…" : open ? "OPEN" : "CLOSED"}
    </span>
  );
  return <>{pill("NYSE", c?.nyse)}{pill("NSE", c?.nse)}</>;
}

function SearchBox() {
  const [q, setQ] = useState("");
  const [res, setRes] = useState<{ symbol: string; name: string; exchange: string }[]>([]);
  const nav = useNavigate();
  useEffect(() => {
    if (q.trim().length < 1) { setRes([]); return; }
    const id = setTimeout(() => { searchSymbols({ data: { q } }).then(setRes).catch(() => setRes([])); }, 250);
    return () => clearTimeout(id);
  }, [q]);
  return (
    <div className="relative w-full max-w-xl">
      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search stocks by symbol or name..." className="w-full rounded-lg border border-input bg-card py-2 pl-9 pr-3 text-sm outline-none focus:border-primary" />
      {res.length > 0 && (
        <div className="absolute z-50 mt-1 w-full overflow-hidden rounded-lg border border-border bg-popover shadow-xl">
          {res.map((r) => (
            <button key={r.symbol} onClick={() => { setQ(""); setRes([]); nav({ to: "/stock/$symbol", params: { symbol: r.symbol } }); }} className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-secondary">
              <span><span className="font-mono font-semibold">{r.symbol}</span> <span className="text-muted-foreground">{r.name}</span></span>
              <span className="text-xs text-muted-foreground">{r.exchange}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Ticker() {
  const { data } = useQuery(snapshotQuery);
  if (!data) return <div className="h-10 border-b border-border" />;
  const items = [...data.stocks, ...data.stocks];
  return (
    <div className="overflow-hidden border-b border-border bg-sidebar py-2.5">
      <div className="flex w-max animate-marquee gap-8 whitespace-nowrap font-mono text-sm">
        {items.map((s, i) => (
          <Link key={i} to="/stock/$symbol" params={{ symbol: s.symbol }} className="flex gap-2">
            <span className="font-semibold">{s.display}</span>
            <span className="text-muted-foreground">{money(s.price, s.currency)}</span>
            <span className={s.changePct >= 0 ? "text-success" : "text-destructive"}>{pctf(s.changePct)}</span>
            <span className="text-border">|</span>
          </Link>
        ))}
      </div>
    </div>
  );
}

function DataNotice() {
  const { data } = useQuery(snapshotQuery);
  if (!data?.unavailable) return null;
  return <div className="border-b border-warning/30 bg-warning/10 px-4 py-2 text-sm text-warning">The market data provider is busy right now. Live prices will appear automatically in a few seconds.</div>;
}

function LiveBadge() {
  const { data, isFetching } = useQuery(snapshotQuery);
  const [t, setT] = useState("");
  useEffect(() => { if (data) setT(new Date(data.fetchedAt).toLocaleTimeString()); }, [data]);
  return (
    <span title="Live quotes from Yahoo Finance (NSE/NYSE/NASDAQ feeds; some exchanges delay up to 15 min). Auto-refreshes every 30 seconds." className="hidden items-center gap-2 rounded-md border border-success/30 px-3 py-1 text-xs text-success lg:inline-flex">
      <Radio className={cn("h-3.5 w-3.5", isFetching && "animate-pulse")} /> Live Data {t && `· ${t}`}
    </span>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-sidebar">
        <div className="flex items-center gap-4 border-b border-border px-4 py-3">
          <Link to="/" className="flex shrink-0 items-center gap-3">
            <img src="/apexquant-logo.png" alt="ApexQuant logo" className="h-10 w-10 rounded-lg object-contain" />
            <div className="hidden sm:block"><div className="font-semibold tracking-wide">APEXQUANT</div><div className="text-xs text-muted-foreground">Explainable Equity Intelligence</div></div>
          </Link>
          <SearchBox />
          <div className="ml-auto hidden items-center gap-2 md:flex"><MarketPills /></div>
          <span title="Data: Yahoo Finance. Fundamentals refresh every few hours; prices every 30s." className="hidden text-muted-foreground lg:inline"><Info className="h-4 w-4" /></span>
          <LiveBadge />
        </div>
        <Ticker />
        <DataNotice />
      </header>
      <div className="flex">
        <nav className="sticky top-[118px] hidden h-[calc(100vh-118px)] w-64 shrink-0 flex-col border-r border-border bg-sidebar p-3 md:flex">
          <div className="space-y-1">
            {NAV.map(({ to, label, icon: I }) => (
              <Link key={to} to={to} activeOptions={{ exact: to === "/" }} className="flex items-center gap-3 rounded-lg border border-transparent px-3 py-2.5 text-sidebar-foreground hover:bg-secondary" activeProps={{ className: "!border-primary/40 bg-sidebar-accent !text-sidebar-accent-foreground" }}>
                <I className="h-5 w-5" />{label}
              </Link>
            ))}
          </div>
          <p className="mt-auto border-t border-border pt-3 text-xs text-muted-foreground">Data to Analysis to Explanation to Decision. Built for Pragati Tech Fest.</p>
        </nav>
        <main className="min-w-0 flex-1 p-4 pb-24 md:p-8">{children}</main>
      </div>
      <nav className="fixed bottom-0 left-0 right-0 z-40 flex overflow-x-auto border-t border-border bg-sidebar md:hidden">
        {NAV.map(({ to, label, icon: I }) => (
          <Link key={to} to={to} activeOptions={{ exact: to === "/" }} className="flex min-w-20 flex-col items-center gap-1 px-2 py-2 text-[10px] text-muted-foreground" activeProps={{ className: "!text-primary" }}><I className="h-5 w-5" />{label.split(" ")[0]}</Link>
        ))}
      </nav>
    </div>
  );
}
