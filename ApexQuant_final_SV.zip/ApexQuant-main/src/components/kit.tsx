import { Star, TrendingDown, TrendingUp } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { pctf } from "@/lib/format";
import { toggleWatch, useStore } from "@/lib/store";

export function Panel({ title, sub, right, children, className }: { title?: ReactNode; sub?: ReactNode; right?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-xl border border-border bg-card p-5", className)}>
      {(title || right) && (
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            {title && <h2 className="text-lg font-semibold">{title}</h2>}
            {sub && <p className="text-sm text-muted-foreground">{sub}</p>}
          </div>
          {right}
        </div>
      )}
      {children}
    </section>
  );
}

export function PageTitle({ icon, children, extra }: { icon: ReactNode; children: ReactNode; extra?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-center gap-3">
      <span className="text-primary">{icon}</span>
      <h1 className="text-2xl font-semibold">{children}</h1>
      {extra}
    </div>
  );
}

export function Change({ v, arrow = false, className }: { v: number; arrow?: boolean; className?: string }) {
  const up = v >= 0;
  return (
    <span className={cn("inline-flex items-center gap-1 font-mono", up ? "text-success" : "text-destructive", className)}>
      {arrow && (up ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />)}
      {pctf(v)}
    </span>
  );
}

export function MarketTag({ m }: { m: string }) {
  return (
    <span className={cn("rounded-md border px-2 py-0.5 font-mono text-xs", m === "US" ? "border-info/40 bg-info/10 text-info" : "border-success/40 bg-success/10 text-success")}>{m}</span>
  );
}

export function ApexBadge({ v }: { v: number }) {
  const c = v >= 60 ? "border-success/40 bg-success/10 text-success" : v >= 45 ? "border-warning/40 bg-warning/10 text-warning" : "border-destructive/40 bg-destructive/10 text-destructive";
  return <span className={cn("inline-flex h-9 w-11 items-center justify-center rounded-lg border font-mono text-sm font-semibold", c)}>{v}</span>;
}

export function StarBtn({ symbol }: { symbol: string }) {
  const { watchlist } = useStore();
  const on = watchlist.includes(symbol);
  return (
    <button aria-label={on ? "Remove from watchlist" : "Add to watchlist"} onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWatch(symbol); }}>
      <Star className={cn("h-4 w-4", on ? "fill-warning text-warning" : "text-muted-foreground hover:text-foreground")} />
    </button>
  );
}

export function Sparkline({ data, w = 90, h = 28 }: { data: number[]; w?: number; h?: number }) {
  if (data.length < 2) return <div style={{ width: w, height: h }} />;
  const min = Math.min(...data), max = Math.max(...data), r = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / r) * h}`).join(" ");
  const up = data[data.length - 1] >= data[0];
  return (
    <svg width={w} height={h} className={up ? "text-success" : "text-destructive"}>
      <polyline points={pts} fill="none" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

export function Empty({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <div className="flex flex-col items-center py-24 text-center">
      <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-xl border border-border bg-card text-muted-foreground">{icon}</div>
      <h2 className="text-xl font-semibold">{title}</h2>
      <div className="mt-2 max-w-md text-muted-foreground">{children}</div>
    </div>
  );
}

export function Stat({ label, value, icon, className }: { label: string; value: ReactNode; icon?: ReactNode; className?: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">{icon}{label}</div>
      <div className={cn("mt-2 font-mono text-2xl", className)}>{value}</div>
    </div>
  );
}

export const btn = "inline-flex items-center justify-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium transition-colors disabled:opacity-50";
export const btnPrimary = cn(btn, "border-primary/40 bg-accent text-accent-foreground hover:bg-accent/80");
export const btnGhost = cn(btn, "border-border bg-card hover:bg-secondary");
export const input = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary";
