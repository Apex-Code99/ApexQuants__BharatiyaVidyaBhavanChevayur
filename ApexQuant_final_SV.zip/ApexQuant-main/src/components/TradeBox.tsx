import { useState } from "react";
import { toast } from "sonner";
import type { Stock } from "@/lib/universe";
import { trade, useStore } from "@/lib/store";
import { money } from "@/lib/format";
import { btnPrimary, btnGhost, input } from "@/components/kit";

export function TradeBox({ s, usdInr }: { s: Stock; usdInr: number }) {
  const { cash, positions } = useStore();
  const [qty, setQty] = useState("1");
  const q = Math.floor(Number(qty));
  const pos = positions.find((p) => p.symbol === s.symbol);
  const costUsd = (s.price * (q || 0)) / (s.currency === "INR" ? usdInr : 1);
  const go = (side: "BUY" | "SELL") => {
    if (!q || q <= 0) { toast.error("Enter a whole number of shares."); return; }
    const err = trade(s.symbol, side, q, s.price, s.currency, usdInr);
    if (err) toast.error(err); else toast.success(`${side === "BUY" ? "Bought" : "Sold"} ${q} ${s.display} at ${money(s.price, s.currency)}`);
  };
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="font-semibold">Paper Trade</h3>
      <p className="mt-1 text-sm text-muted-foreground">Executes at the live price. Cash: {money(cash)}</p>
      <label className="mt-4 block text-sm text-muted-foreground">Quantity</label>
      <input className={input} value={qty} onChange={(e) => setQty(e.target.value)} inputMode="numeric" />
      <p className="mt-2 text-sm text-muted-foreground">Order value ≈ {money(costUsd)}{s.currency === "INR" && ` (₹ at live USD/INR ${usdInr.toFixed(2)})`}</p>
      {pos && <p className="mt-1 text-sm">You hold {pos.qty} @ {money(pos.avgPrice, pos.currency)}</p>}
      <div className="mt-4 grid grid-cols-2 gap-2">
        <button onClick={() => go("BUY")} className={btnPrimary}>Buy</button>
        <button onClick={() => go("SELL")} className={btnGhost}>Sell</button>
      </div>
    </div>
  );
}
