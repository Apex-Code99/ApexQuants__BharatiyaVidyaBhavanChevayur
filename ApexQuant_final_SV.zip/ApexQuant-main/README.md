# ApexQuant

ApexQuant is a stock research dashboard I am building for a student project. It puts a selected list of US and Indian stocks in one place, so I can look at prices, compare companies, test simple strategies, and learn how risk measures work.

It is for learning and research. It is **not** a broker, it does not place real orders, and it does not tell people which stocks to buy or sell.

## What the app can do

- **Command Center (`/`)** — a quick view of the market and selected stocks.
- **Live Markets (`/markets`)** — quotes for the stocks listed in `src/lib/universe.ts`.
- **Screener (`/screener`)** — filter the available stocks and view their Apex Scores.
- **Stock research (`/stock/$symbol`)** — view a stock's details and historical prices.
- **Compare (`/compare`)** — compare selected stocks.
- **Watchlist (`/watchlist`)** — save symbols in this browser.
- **Paper Portfolio (`/portfolio`)** — practise buying and selling with a pretend starting balance of $100,000.
- **Risk Engine (`/risk`)** — estimate volatility, Value at Risk (VaR), beta, and drawdown using historical prices.
- **Strategy Lab (`/strategy`)** — test a simple moving-average crossover against past closing prices.
- **Innovate for Impact (`/impact`)** — explain the problem the project is trying to address.

This is a work in progress, so not every feature has been tested in every situation. The code shows what is actually implemented. If a data provider is down, some values or pages may not load.

## Before you start

You need a current Node.js version compatible with the packages in `package.json`. npm is fine; the project also includes a Bun lockfile.

```bash
npm install
npm run dev
```

Open the local URL printed in the terminal. To stop the development server, press `Ctrl+C`.

## Logo

The header uses the ApexQuant logo stored at `public/apexquant-logo.png`. The same asset can be used for the app icon in future packaging.

## Where the data comes from

Market prices, historical closes, company details, and news are requested from Yahoo Finance public endpoints by `src/lib/market.functions.ts`. These endpoints are unofficial. They can change, slow down, block requests, or return incomplete information. The app has short-lived in-memory caches, and some requests may fall back to previously cached data.

A few limitations to remember:

- The stock list is selected by the project; it is not every stock in the US or India. See `src/lib/universe.ts`.
- The USD/INR value falls back to 83 if the provider does not return a rate. That fallback is not a live quote.
- News labels are assigned using simple keyword matching. They are not a proper sentiment model.
- Missing financial metrics may get a neutral score, so check the original values too.
- Paper trades are simulated and stored in this browser. They do not use real money or connect to a broker.
- Risk estimates and backtests use past data. Backtests do not fully model fees, taxes, slippage, or market impact.

## How the Apex Score works

The score is a fixed calculation in `computeApex()` inside `src/lib/universe.ts`. It is **not created by the AI model**. Each part is scored from 0 to 100, then the five parts are averaged equally.

| Part | What it looks at |
| --- | --- |
| Valuation | P/E ratio. A lower positive P/E scores higher within the chosen range. Missing or non-positive P/E starts at 30. |
| Growth | Revenue growth and earnings growth, averaged together. |
| Profitability | Return on equity and net margin. |
| Health | Debt-to-equity and current ratio. |
| Momentum | Position in the 52-week range and the daily percentage move. |

The formula uses set ranges rather than a detailed financial model. If a metric is missing, its mapping can return 50. This makes the calculation predictable, but it can make a score look more certain than the data really is. I use the score as a quick comparison aid, not as a recommendation to buy or sell anything.

## How some calculations work

- **Paper trading:** cash is stored in USD. Indian-stock trade values are converted using the USD/INR rate passed into the trade. The app updates holdings, cash, average purchase price, and trade history.
- **Annualized volatility:** daily return standard deviation multiplied by the square root of 252.
- **Parametric VaR:** a one-day estimate using 1.645 times daily portfolio volatility and portfolio value.
- **Historical VaR:** based on the lower end of the observed daily return series.
- **Beta:** compares portfolio returns with the S&P 500 over matching dates.
- **Maximum drawdown:** the biggest observed fall from a previous portfolio peak.
- **Strategy Lab:** buys when the fast simple moving average crosses above the slow one and sells when it crosses below.

These are simplified calculations for learning. VaR is not the worst possible loss, and past performance does not predict future results. More detail is in [`docs/FINANCIAL_CALCULATIONS.md`](docs/FINANCIAL_CALCULATIONS.md).

## Project structure

```text
src/
  components/          Shared app layout and reusable UI components
  lib/
    market.functions.ts  Market data, caching, and symbol search
    universe.ts          Stock list, types, and Apex Score formula
    store.ts             Watchlist and paper portfolio state
    positions.ts         Current prices used for portfolio holdings
    queries.ts           Shared data-fetching definitions
    format.ts            Number and currency formatting
  routes/              Pages such as markets, screener, risk, and portfolio
  test/                Automated tests
  router.tsx           Router setup
  start.ts             Server middleware and request protection
  server.ts            Server request entry and error handling
docs/
  ARCHITECTURE.md
  FINANCIAL_CALCULATIONS.md
```

For a walkthrough of how the pieces connect, see [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Commands

```bash
npm run dev        # Start the app locally
npm test           # Run tests once
npm run test:watch # Keep tests running while editing
npm run lint       # Check code style and common mistakes
npm run typecheck  # Check TypeScript types
npm run build      # Make a production build
npm run preview    # Preview the production build
```

Run the commands from the project folder. A successful build does not prove that every external API works, so test market data separately.

## Testing before a presentation

1. Run `npm test`, `npm run lint`, `npm run typecheck`, and `npm run build`.
2. Open each page you plan to show.
3. Check that market data loads on the network you will use.
4. Try one paper BUY and SELL, then check the cash and position values.
5. Confirm the data timestamp and explain the limitations of the public data source.

The test suite checks some Apex Score and portfolio rules, but it does not cover every calculation or every possible API failure.

## Technologies

React, TypeScript, TanStack Start, TanStack Router, TanStack Query, Vite, Tailwind CSS, Vitest, and Yahoo Finance public endpoints.

## Credits and ownership

This project uses open-source libraries and reusable UI components so I can focus on connecting the data, building the research tools, and learning how the calculations work. I will explain the main parts I present and be honest about the documentation, examples, and development tools that helped me. I do not claim that every line was written from scratch.

## Licence

There is no separate licence for ApexQuant in this repository. Check each dependency's licence before redistributing it.
